# Enfactum AI Assistant

A self-hosted, permission-aware AI assistant built to plug into **Enfactum OS** (Laravel / Filament / React).
It answers from three kinds of knowledge and routes every question to the right one:

| Question type | Source | How |
|---|---|---|
| General knowledge | The LLM itself | Answered directly, no tools, lowest latency |
| Public / current information | Web search | Tavily (if key set) or DuckDuckGo, with inline citations |
| Private Enfactum information | Company documents + Enfactum OS APIs | Permission-filtered hybrid RAG + read-only OS API tools called **with the employee's own credentials** |

The UI is a streaming chat with cited sources, conversation history, source modes (Auto / General / Web / Company), and a knowledge-base manager with document-level access control.

---

## Quick start (5 minutes)

**Requirements:** Python 3.10+ (or Docker) and an API key for any OpenAI-compatible LLM that supports tool calling.

```bash
unzip enfactum-ai-agent.zip && cd enfactum-ai-agent
cp .env.example .env          # then set LLM_API_KEY=...
./run.sh                      # Windows: run.bat
```

Open <http://localhost:8080>.

**Docker instead:**

```bash
cp .env.example .env          # set LLM_API_KEY
docker compose up -d --build
```

Out of the box it runs in **demo mode**: three fictional employees (switch between them in the sidebar), three sample policy documents, and a bundled mock Enfactum OS. That lets you check that permissions work before connecting the real OS:

| Demo user | Can see |
|---|---|
| Aisha Khan (super_admin) | Everything, manages the knowledge base |
| Rohan Mehta (hr_manager) | Employee directory incl. salaries, HR-only compensation guidelines |
| Priya Nair (project_manager) | Only her own projects (no budgets), clients; no employee directory |

Ask each of them *"What are the merit increase bands?"*, *"List all projects with budgets"*, or *"What is Sara Iyer's salary?"* and compare the answers.

### Fully local / offline LLM

Point it at Ollama (or LM Studio / vLLM). Use a model with solid tool calling, e.g. `qwen2.5:14b` or `llama3.1:8b`:

```env
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=qwen2.5:14b
EMBEDDING_PROVIDER=local        # pip install -r requirements-optional.txt
```

---

## Connecting to the real Enfactum OS

See **[docs/ENFACTUM_OS_INTEGRATION.md](docs/ENFACTUM_OS_INTEGRATION.md)**. In short:

1. `AUTH_MODE=laravel`, `OS_BASE_URL=https://os.enfactum...`, `ENVIRONMENT=production`, `MOCK_OS_ENABLED=false`, `SEED_SAMPLE_DOCS=false`.
2. Make sure `GET /api/user` (Sanctum) returns the user's roles and permissions, and map the fields with `OS_USER_*_FIELD`.
3. Declare the existing read-only OS endpoints the assistant may call in `config/os_tools.yaml` and set `OS_TOOLS_FILE=config/os_tools.yaml`.
4. Embed the assistant in the OS frontend (iframe with `?embed=1`, or call `/api/chat` from React).

No code changes are needed in this repository; everything is configuration.

---

## Configuration

Everything lives in `.env`, and `.env.example` documents every variable. The key ones:

| Variable | Purpose |
|---|---|
| `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` | Any OpenAI-compatible endpoint (OpenAI, Azure, Groq, OpenRouter, Ollama, vLLM…) |
| `EMBEDDING_PROVIDER` | `llm` (API), `local` (fastembed on CPU), `none` (keyword search only) |
| `WEB_SEARCH_PROVIDER`, `TAVILY_API_KEY` | `auto` picks Tavily if a key is set, otherwise DuckDuckGo |
| `AUTH_MODE` | `demo`, `laravel` (validate via OS `/api/user`), `jwt` (verify OS-issued JWT) |
| `OS_TOOLS_FILE` | YAML list of read-only OS endpoints exposed as tools |
| `PERM_CHAT`, `PERM_WEB_SEARCH`, `PERM_DOCUMENTS_MANAGE` | OS permission names that gate assistant features |

**Recommended models:** `gpt-4o-mini` / `gpt-4.1-mini` give the best speed-to-accuracy ratio; use `gpt-4o` / `gpt-4.1` for maximum accuracy.

---

## HTTP API

| Method & path | Description |
|---|---|
| `POST /api/chat` | `{message, conversation_id?, mode}` → Server-Sent Events: `conversation`, `status`, `token`, `sources`, `done`, `error` |
| `GET /api/me` | Resolved identity and capabilities |
| `GET/DELETE /api/conversations[/{id}]` | The caller's own conversation history |
| `GET/POST/DELETE /api/documents[/{id}]` | Knowledge base (upload needs `PERM_DOCUMENTS_MANAGE`) |
| `GET /api/health`, `GET /api/config` | Health check, public UI config |

Interactive docs are at `/api/docs` when not in production.

## Project layout

```text
app/
  main.py            FastAPI app, routes, SSE streaming
  agent.py           Tool-calling orchestration loop (parallel tools, citations, streaming)
  prompts.py         System prompt: source routing, grounding and security rules
  auth.py            Identity: demo / Laravel Sanctum / JWT → UserContext
  llm.py             OpenAI-compatible client
  rag/               Parsers, chunker, embeddings, hybrid BM25+vector index with ACL
  tools/             web_search, search_company_documents, YAML-driven Enfactum OS API tools
  mock_os.py         Demo stand-in for Enfactum OS (disabled in production)
static/              Chat UI (no build step)
config/              os_tools.yaml (production), os_tools.demo.yaml, demo_users.yaml
samples/             Fictional demo documents
docs/                Architecture, security model, Enfactum OS integration
tests/               pytest suite (pip install -r requirements-optional.txt && pytest)
```

## Documentation

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md): components, request flow, performance design, scaling
- [docs/SECURITY.md](docs/SECURITY.md): the mandatory security constraints and how each is enforced
- [docs/ENFACTUM_OS_INTEGRATION.md](docs/ENFACTUM_OS_INTEGRATION.md): step-by-step Laravel/React integration
