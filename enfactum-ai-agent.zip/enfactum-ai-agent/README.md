# Enfactum AI Assistant

A self-hosted, permission-aware AI assistant for Enfactum employees, built to plug into **Enfactum OS** (Laravel / Filament / React / PostgreSQL). It answers from every kind of knowledge and routes each question to the right source:

| Question type | Source | How |
|---|---|---|
| General knowledge | The LLM itself | Answered directly, lowest latency |
| Public / current information | Web search | Tavily (if key set) or DuckDuckGo, with inline citations |
| Company knowledge | Knowledge base | Role-filtered hybrid search over uploaded policies and manuals |
| Your own files | Chat attachments | Files and images attached with **+** in the message bar |
| Live company data | Enfactum OS APIs / read-only DB templates | Called with the **employee's own credentials**, so OS RBAC applies |

**UI:**
- Streaming answers with clickable citations.
- Sidebar with chat search, pinned and recent chats; rename, pin or delete from the ⋯ menu.
- Answer-source modes: Auto / General / Web / Company.
- Attach files or images, by button, drag-and-drop or paste.
- Context-window meter.
- Full **Settings**: General, Personalization, Chats & history, Knowledge base, Account, About.

---

## Quick start

**Requirements:** Python 3.10+ (or Docker) and an API key for a tool-calling LLM.

```bash
cd enfactum-ai-agent
cp .env.example .env          # set LLM_API_KEY=...  (the server reads only .env)
./run.sh                      # Windows: run.bat    Docker: docker compose up -d --build
```

Open <http://localhost:8080>, then go to **Settings → About → Test connection**.

The provider is detected from the key:

| Key prefix | Provider |
|---|---|
| `sk-` | OpenAI |
| `AIza` | Gemini |
| `gsk_` | Groq |
| `sk-or-` | OpenRouter |
| `sk-ant-` | Anthropic |

Ollama and vLLM also work. See `.env.example`.

Local mode signs you in as **one test employee** against a bundled mock Enfactum OS with sample policies. In production, identity, roles and permissions come from Enfactum OS.

## Connecting to Enfactum OS

Everything is in **[docs/INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md)**:

- sign-in: Sanctum token, shared cookie or JWT
- RBAC mapping
- live data through OS API tools or read-only SQL templates
- loading company documents, including bulk sync
- embedding in React and Filament
- deployment, testing and troubleshooting

No code changes are needed in this repository; it is all configuration.

## Documentation

| Doc | Contents |
|---|---|
| [docs/INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md) | Step-by-step integration with Enfactum OS, databases and company knowledge |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Components, request flow, accuracy and performance design |
| [docs/SECURITY.md](docs/SECURITY.md) | Mandatory security constraints and how each is enforced |
| [docs/AGENTIC_ROADMAP.md](docs/AGENTIC_ROADMAP.md) | Adding safe, confirmed actions (agentic AI) |

## Project layout

```text
app/
  main.py            FastAPI app and HTTP API
  agent.py           Tool-calling loop: parallel tools, citations, attachments, context budgeting, streaming
  prompts.py         Source routing, grounding, security rules, personalization
  auth.py            Identity: demo / Laravel Sanctum / JWT → UserContext
  llm.py             OpenAI-compatible client, provider detection, clear error messages
  attachments.py     Per-chat files and images
  rag/               Parsers, chunker, embeddings, hybrid BM25+vector index with role filtering
  tools/             web_search, company documents, Enfactum OS API tools, read-only DB templates
  mock_os.py         Local stand-in for Enfactum OS (disabled in production)
static/              UI (no build step)
config/              os_tools.yaml, db_tools.yaml, demo_users.yaml, os_tools.demo.yaml
scripts/             ingest_folder.py (bulk knowledge-base upload)
tests/               pytest suite
```
