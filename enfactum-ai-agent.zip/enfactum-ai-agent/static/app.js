(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = window.Markdown.escape;

  const ICONS = {
    auto: '<svg viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/></svg>',
    general: '<svg viewBox="0 0 24 24"><path d="M9.5 3a5.5 5.5 0 0 0-3.2 10v2.5A1.5 1.5 0 0 0 7.8 17h8.4a1.5 1.5 0 0 0 1.5-1.5V13A5.5 5.5 0 0 0 14.5 3z"/><path d="M9 21h6"/></svg>',
    web: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
    company: '<svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-4h6v4M9 10h.01M15 10h.01M9 14h.01M15 14h.01"/></svg>',
    document: '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
    os: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M5 12l5 5 9-10"/></svg>',
    copy: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>',
    lock: '<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    retry: '<svg viewBox="0 0 24 24"><path d="M4 12a8 8 0 0 1 14-5.3L20 9M20 4v5h-5M20 12a8 8 0 0 1-14 5.3L4 15M4 20v-5h5"/></svg>',
  };
  const MODES = [
    { id: "auto", label: "Auto", title: "Automatically choose the best source" },
    { id: "general", label: "General", title: "Answer from the model's own knowledge" },
    { id: "web", label: "Web", title: "Search the public web for current information" },
    { id: "company", label: "Company", title: "Enfactum documents and live OS data only" },
  ];
  const SUGGESTIONS = [
    { kind: "company", tag: "Company policy", text: "How many days of annual leave do I get, and how much can I carry forward?" },
    { kind: "os", tag: "Live OS data", text: "Which projects am I currently working on?" },
    { kind: "web", tag: "Current events", text: "What are the latest developments in enterprise AI this week?" },
    { kind: "general", tag: "General", text: "Draft a concise status-update email template for a client project." },
  ];

  const state = {
    config: null, me: null, mode: "auto", conversationId: null, streaming: false, controller: null,
    token: sessionStorage.getItem("enfactum_ai_token") || "",
    demoUser: localStorage.getItem("enfactum_ai_demo_user") || "",
  };

  // ------------------------------------------------------------------ API
  function headers(extra) {
    const h = Object.assign({}, extra || {});
    if (state.token) h.Authorization = "Bearer " + state.token;
    if (state.config && state.config.auth_mode === "demo" && state.demoUser) h["X-Demo-User"] = state.demoUser;
    return h;
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, Object.assign({}, opts, { headers: headers(opts.headers), credentials: "same-origin" }));
    if (res.status === 401 && state.config && state.config.auth_mode !== "demo") {
      showTokenModal();
      throw new Error("Please sign in.");
    }
    if (!res.ok) {
      let detail = res.statusText;
      try { detail = (await res.json()).detail || detail; } catch (_) { /* not JSON */ }
      throw new Error(typeof detail === "string" ? detail : "Request failed");
    }
    return res;
  }
  const getJSON = async (path) => (await api(path)).json();

  // ------------------------------------------------------------------ UI helpers
  function toast(message, isError) {
    const el = document.createElement("div");
    el.className = "toast" + (isError ? " error" : "");
    el.textContent = message;
    $("toasts").appendChild(el);
    setTimeout(() => el.remove(), 4000);
  }
  const initials = (name) => (name || "?").split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const hostOf = (url) => { try { return new URL(url).hostname.replace(/^www\./, ""); } catch (_) { return ""; } };
  function scrollToBottom(force) {
    const t = $("thread");
    if (force || t.scrollHeight - t.scrollTop - t.clientHeight < 160) t.scrollTop = t.scrollHeight;
  }
  function greeting() {
    const h = new Date().getHours();
    const part = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
    const first = state.me ? state.me.user.name.split(" ")[0] : "";
    return first ? `${part}, ${first}` : part;
  }

  // ------------------------------------------------------------------ bootstrap
  async function init() {
    const params = new URLSearchParams(location.search);
    if (params.get("embed") === "1") $("app").classList.add("embed");
    const hash = new URLSearchParams(location.hash.slice(1));
    if (hash.get("token")) {
      state.token = hash.get("token");
      sessionStorage.setItem("enfactum_ai_token", state.token);
      history.replaceState(null, "", location.pathname + location.search);
    }
    let configLoaded;
    const configReady = new Promise((resolve) => (configLoaded = resolve));
    window.addEventListener("message", async (e) => {
      if (!e.data || e.data.type !== "enfactum-ai-token") return;
      await configReady;
      if (e.origin !== location.origin && !(state.config.trusted_origins || []).includes(e.origin)) return;
      if (typeof e.data.token === "string" && e.data.token) {
        state.token = e.data.token;
        sessionStorage.setItem("enfactum_ai_token", state.token);
        loadIdentity();
      }
    });

    renderModes();
    renderSuggestions();
    bindEvents();
    try {
      state.config = await (await fetch("/api/config")).json();
    } catch (_) {
      toast("Cannot reach the assistant server.", true);
      return;
    }
    configLoaded();
    document.title = state.config.app_name;
    $("brandName").textContent = state.config.app_name.replace(/ Assistant$/, "");
    if (state.config.auth_mode === "demo") setupDemoUsers();
    $("dropHint").textContent = `${state.config.supported_extensions.join(", ")} · max ${state.config.max_upload_mb} MB`;
    if (state.config.auth_mode !== "demo" && !state.token && !state.config.cookie_auth) {
      // Embedded: wait for the host page to postMessage the token. Standalone: ask for it.
      if (!$("app").classList.contains("embed")) showTokenModal();
      return;
    }
    await loadIdentity();
  }

  function setupDemoUsers() {
    const users = state.config.demo_users || [];
    if (!users.find((u) => u.id === state.demoUser)) state.demoUser = users.length ? users[0].id : "";
    const sel = $("demoUser");
    sel.innerHTML = users.map((u) => `<option value="${esc(u.id)}">${esc(u.name)}${u.title ? " — " + esc(u.title) : ""}</option>`).join("");
    sel.value = state.demoUser;
    $("demoSwitch").classList.remove("hidden");
  }

  async function loadIdentity() {
    try {
      state.me = await getJSON("/api/me");
    } catch (e) {
      toast(e.message, true);
      return;
    }
    const u = state.me.user;
    $("userName").textContent = u.name;
    $("userRoles").textContent = u.roles.join(", ") || "employee";
    $("userAvatar").textContent = initials(u.name);
    $("greeting").textContent = greeting();
    renderCapabilities();
    renderModes();
    newChat();
    loadConversations();
  }

  function renderCapabilities() {
    const c = state.me.capabilities;
    const caps = [
      ["Web search", c.web_search],
      ["Company docs", true],
      [c.os_tools.length ? `OS data · ${c.os_tools.length}` : "OS data", c.os_tools.length > 0],
    ];
    $("capabilities").innerHTML = caps.map(([label, on]) =>
      `<span class="cap${on ? "" : " off"}" title="${on ? "Available" : "Not available for your account"}"><i></i>${esc(label)}</span>`).join("");
  }

  function renderModes() {
    const webOff = state.me && !state.me.capabilities.web_search;
    if (webOff && state.mode === "web") state.mode = "auto";
    $("modes").innerHTML = MODES.map((m) => {
      const disabled = m.id === "web" && webOff;
      return `<button type="button" role="radio" class="mode${state.mode === m.id ? " active" : ""}" data-mode="${m.id}"` +
        ` aria-checked="${state.mode === m.id}" title="${esc(m.title)}"${disabled ? " disabled" : ""}>${ICONS[m.id]}${m.label}</button>`;
    }).join("");
  }

  function renderSuggestions() {
    $("suggestions").innerHTML = SUGGESTIONS.map((s, i) =>
      `<button type="button" class="suggestion" data-i="${i}"><small>${ICONS[s.kind === "os" ? "os" : s.kind === "company" ? "document" : s.kind === "web" ? "web" : "general"]}${esc(s.tag)}</small><span>${esc(s.text)}</span></button>`).join("");
  }

  // ------------------------------------------------------------------ conversations
  async function loadConversations() {
    try {
      const data = await getJSON("/api/conversations");
      const list = $("convList");
      if (!data.conversations.length) {
        list.innerHTML = '<div class="conv-empty">No conversations yet</div>';
        return;
      }
      list.innerHTML = data.conversations.map((c) =>
        `<div class="conv-item${c.id === state.conversationId ? " active" : ""}" data-id="${esc(c.id)}" role="button" tabindex="0">` +
        `<span>${esc(c.title)}</span><button class="del" type="button" data-del="${esc(c.id)}" aria-label="Delete">${ICONS.trash}</button></div>`).join("");
    } catch (_) { /* surfaced elsewhere */ }
  }

  function newChat() {
    if (state.streaming) stop();
    state.conversationId = null;
    $("messages").innerHTML = "";
    $("welcome").classList.remove("hidden");
    $("convTitle").textContent = "New chat";
    document.querySelectorAll(".conv-item.active").forEach((el) => el.classList.remove("active"));
    $("input").focus();
    closeNav();
  }

  async function openConversation(id) {
    if (state.streaming) stop();
    try {
      const conv = await getJSON(`/api/conversations/${encodeURIComponent(id)}`);
      state.conversationId = conv.id;
      $("convTitle").textContent = conv.title;
      $("welcome").classList.add("hidden");
      $("messages").innerHTML = "";
      for (const m of conv.messages) {
        if (m.role === "user") addUserMessage(m.content);
        else {
          const view = addAssistantMessage();
          view.text = m.content;
          view.finish(m.sources, m.meta);
        }
      }
      loadConversations();
      scrollToBottom(true);
      closeNav();
    } catch (e) { toast(e.message, true); }
  }

  async function deleteConversation(id) {
    if (!confirm("Delete this conversation?")) return;
    try {
      await api(`/api/conversations/${encodeURIComponent(id)}`, { method: "DELETE" });
      if (id === state.conversationId) newChat();
      loadConversations();
    } catch (e) { toast(e.message, true); }
  }

  // ------------------------------------------------------------------ messages
  function addUserMessage(text) {
    const el = document.createElement("div");
    el.className = "msg-user";
    el.textContent = text;
    $("messages").appendChild(el);
  }

  function addAssistantMessage() {
    const root = document.createElement("div");
    root.className = "msg-ai";
    root.innerHTML = '<div class="welcome-logo ai-avatar">E</div><div class="msg-body"><div class="steps"></div>' +
      '<div class="typing"><i></i><i></i><i></i></div><div class="md"></div><div class="sources hidden"></div><div class="msg-actions hidden"></div></div>';
    $("messages").appendChild(root);
    const q = (s) => root.querySelector(s);
    const view = {
      root, text: "", steps: {}, pending: false,
      step(ev) {
        q(".typing").classList.add("hidden");
        if (ev.state === "running") {
          const s = document.createElement("div");
          s.className = "step";
          s.innerHTML = `<span class="dot"><span class="spinner"></span></span><span></span>`;
          s.lastChild.textContent = ev.label;
          q(".steps").appendChild(s);
          view.steps[ev.id] = s;
        } else if (view.steps[ev.id]) {
          view.steps[ev.id].classList.add("done");
          view.steps[ev.id].querySelector(".dot").innerHTML = ICONS.check;
        }
        scrollToBottom();
      },
      append(token) {
        view.text += token;
        q(".typing").classList.add("hidden");
        if (!view.pending) {
          view.pending = true;
          requestAnimationFrame(() => {
            view.pending = false;
            const md = q(".md");
            md.innerHTML = window.Markdown.render(view.text);
            md.classList.add("caret");
            scrollToBottom();
          });
        }
      },
      error(message) {
        q(".typing").classList.add("hidden");
        const e = document.createElement("div");
        e.className = "msg-error";
        e.textContent = message;
        q(".msg-body").insertBefore(e, q(".sources"));
      },
      finish(sources, meta) {
        q(".typing").classList.add("hidden");
        const md = q(".md");
        md.classList.remove("caret");
        md.innerHTML = window.Markdown.render(view.text);
        renderSources(q(".sources"), sources || []);
        const actions = q(".msg-actions");
        if (view.text) {
          const latency = meta && meta.latency_ms ? `${(meta.latency_ms / 1000).toFixed(1)}s` : "";
          actions.innerHTML = `<button type="button" data-act="copy" title="Copy answer">${ICONS.copy}Copy</button>` +
            (latency ? `<span>· ${latency}</span>` : "");
          actions.classList.remove("hidden");
          actions.querySelector('[data-act="copy"]').addEventListener("click", () => {
            navigator.clipboard.writeText(view.text.replace(/\[(\d{1,3})\]/g, "")).then(() => toast("Copied"));
          });
        }
      },
    };
    return view;
  }

  function renderSources(el, sources) {
    if (!sources.length) return;
    el.innerHTML = '<div class="sources-title">Sources</div><div class="source-grid"></div>';
    const grid = el.lastChild;
    for (const s of sources) {
      const isLink = s.url && /^https?:\/\//.test(s.url);
      const card = document.createElement(isLink ? "a" : "div");
      card.className = "source";
      card.dataset.n = s.n;
      if (isLink) { card.href = s.url; card.target = "_blank"; card.rel = "noopener noreferrer"; }
      const icon = s.type === "web" ? ICONS.web : s.type === "os" ? ICONS.os : ICONS.document;
      const sub = s.type === "web" ? hostOf(s.url) : s.type === "os" ? "Enfactum OS · live data" : "Company document";
      card.innerHTML = `<span class="num">${Number(s.n)}</span><span class="s-body"><strong></strong><small>${icon}<span></span></small></span>`;
      card.querySelector("strong").textContent = s.title;
      card.querySelector("small span").textContent = sub;
      if (s.snippet) card.title = s.snippet;
      grid.appendChild(card);
    }
    el.classList.remove("hidden");
  }

  // ------------------------------------------------------------------ chat
  async function send(text) {
    text = (text || "").trim();
    if (!text || state.streaming) return;
    $("welcome").classList.add("hidden");
    $("input").value = "";
    autosize();
    addUserMessage(text);
    const view = addAssistantMessage();
    scrollToBottom(true);
    setStreaming(true);
    state.controller = new AbortController();
    let sources = [], meta = {};
    try {
      const res = await api("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, conversation_id: state.conversationId, mode: state.mode }),
        signal: state.controller.signal,
      });
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx;
        while ((idx = buffer.indexOf("\n\n")) >= 0) {
          const raw = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          const line = raw.split("\n").find((l) => l.startsWith("data: "));
          if (!line) continue;
          const ev = JSON.parse(line.slice(6));
          if (ev.type === "conversation") {
            const isNew = !state.conversationId;
            state.conversationId = ev.id;
            if (isNew) { $("convTitle").textContent = text.length > 60 ? text.slice(0, 60) + "…" : text; loadConversations(); }
          } else if (ev.type === "token") view.append(ev.text);
          else if (ev.type === "status") view.step(ev);
          else if (ev.type === "sources") sources = ev.sources;
          else if (ev.type === "error") view.error(ev.message);
          else if (ev.type === "done") meta = ev;
        }
      }
    } catch (e) {
      if (e.name !== "AbortError") view.error(e.message || "Connection lost.");
    } finally {
      view.finish(sources, meta);
      setStreaming(false);
      loadConversations();
    }
  }

  function stop() {
    if (state.controller) state.controller.abort();
  }

  function setStreaming(on) {
    state.streaming = on;
    $("sendBtn").classList.toggle("stop", on);
    $("sendBtn").setAttribute("aria-label", on ? "Stop" : "Send");
    updateSendState();
  }
  function updateSendState() {
    $("sendBtn").disabled = !state.streaming && !$("input").value.trim();
  }
  function autosize() {
    const t = $("input");
    t.style.height = "auto";
    t.style.height = Math.min(t.scrollHeight, 220) + "px";
    updateSendState();
  }

  // ------------------------------------------------------------------ documents
  async function openDocs() {
    $("docsDrawer").classList.remove("hidden");
    await loadDocs();
  }
  async function loadDocs() {
    const list = $("docList");
    list.innerHTML = '<div class="empty">Loading…</div>';
    try {
      const data = await getJSON("/api/documents");
      $("uploadForm").classList.toggle("hidden", !data.can_manage);
      if (!data.documents.length) {
        list.innerHTML = '<div class="empty">No documents available to you yet.</div>';
        return;
      }
      list.innerHTML = "";
      for (const d of data.documents) {
        const row = document.createElement("div");
        row.className = "doc";
        const restricted = d.visibility && d.visibility.scope === "restricted";
        const kb = d.size_bytes > 1048576 ? (d.size_bytes / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(d.size_bytes / 1024)) + " KB";
        row.innerHTML = `<div class="doc-icon">${ICONS.document}</div><div class="doc-meta"><strong></strong>` +
          `<small>${esc(d.filename)} · ${kb} · ${d.chunk_count} sections</small>` +
          (restricted ? `<span class="badge lock" title="Visible to: ${esc((d.visibility.roles || []).join(", "))}">Restricted</span>` : "") +
          `</div>` + (data.can_manage ? `<button class="icon-btn" type="button" aria-label="Delete">${ICONS.trash}</button>` : "");
        row.querySelector("strong").textContent = d.title;
        const del = row.querySelector("button");
        if (del) del.addEventListener("click", () => deleteDoc(d));
        list.appendChild(row);
      }
    } catch (e) {
      list.innerHTML = "";
      toast(e.message, true);
    }
  }
  async function deleteDoc(d) {
    if (!confirm(`Remove “${d.title}” from the knowledge base?`)) return;
    try {
      await api(`/api/documents/${encodeURIComponent(d.id)}`, { method: "DELETE" });
      toast("Document removed");
      loadDocs();
    } catch (e) { toast(e.message, true); }
  }
  let pendingFile = null;
  function pickFile(file) {
    pendingFile = file || null;
    $("dropText").textContent = file ? file.name : "Drop a file or browse";
    $("uploadBtn").disabled = !file;
  }
  async function upload(e) {
    e.preventDefault();
    if (!pendingFile) return;
    const fd = new FormData();
    fd.append("file", pendingFile);
    fd.append("title", $("docTitle").value.trim());
    fd.append("visibility", $("docVisibility").value);
    fd.append("roles", $("docRoles").value.trim());
    const btn = $("uploadBtn");
    btn.disabled = true;
    btn.textContent = "Indexing…";
    try {
      const r = await (await api("/api/documents", { method: "POST", body: fd })).json();
      toast(`Indexed “${r.title}” (${r.chunks} sections)`);
      $("uploadForm").reset();
      $("docRoles").classList.add("hidden");
      pickFile(null);
      loadDocs();
    } catch (err) {
      toast(err.message, true);
      btn.disabled = false;
    } finally {
      btn.textContent = "Upload & index";
    }
  }

  // ------------------------------------------------------------------ auth modal / nav
  function showTokenModal() { $("tokenModal").classList.remove("hidden"); $("tokenInput").focus(); }
  function closeNav() { $("app").classList.remove("nav-open"); }

  // ------------------------------------------------------------------ events
  function bindEvents() {
    $("composer").addEventListener("submit", (e) => { e.preventDefault(); state.streaming ? stop() : send($("input").value); });
    $("input").addEventListener("input", autosize);
    $("input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!state.streaming) send($("input").value); }
    });
    $("modes").addEventListener("click", (e) => {
      const b = e.target.closest(".mode");
      if (!b || b.disabled) return;
      state.mode = b.dataset.mode;
      renderModes();
      $("input").focus();
    });
    $("suggestions").addEventListener("click", (e) => {
      const b = e.target.closest(".suggestion");
      if (b) send(SUGGESTIONS[+b.dataset.i].text);
    });
    $("newChat").addEventListener("click", newChat);
    $("convList").addEventListener("click", (e) => {
      const del = e.target.closest("[data-del]");
      if (del) { e.stopPropagation(); deleteConversation(del.dataset.del); return; }
      const item = e.target.closest(".conv-item");
      if (item) openConversation(item.dataset.id);
    });
    $("convList").addEventListener("keydown", (e) => {
      const item = e.target.closest(".conv-item");
      if (item && e.key === "Enter") openConversation(item.dataset.id);
    });
    $("messages").addEventListener("click", (e) => {
      const cite = e.target.closest(".cite");
      if (cite) {
        const card = cite.closest(".msg-body").querySelector(`.source[data-n="${cite.dataset.n}"]`);
        if (card) {
          card.scrollIntoView({ behavior: "smooth", block: "nearest" });
          card.classList.add("flash");
          setTimeout(() => card.classList.remove("flash"), 1400);
        }
        return;
      }
      const copy = e.target.closest(".copy-code");
      if (copy) {
        navigator.clipboard.writeText(copy.closest(".code").querySelector("code").textContent)
          .then(() => { copy.textContent = "Copied"; setTimeout(() => (copy.textContent = "Copy"), 1200); });
      }
    });
    $("demoUser").addEventListener("change", (e) => {
      state.demoUser = e.target.value;
      localStorage.setItem("enfactum_ai_demo_user", state.demoUser);
      loadIdentity();
    });
    $("openDocs").addEventListener("click", openDocs);
    $("closeDocs").addEventListener("click", () => $("docsDrawer").classList.add("hidden"));
    $("docsDrawer").addEventListener("click", (e) => { if (e.target.id === "docsDrawer") $("docsDrawer").classList.add("hidden"); });
    $("docVisibility").addEventListener("change", (e) => $("docRoles").classList.toggle("hidden", e.target.value !== "restricted"));
    $("fileInput").addEventListener("change", (e) => pickFile(e.target.files[0]));
    const dz = $("dropzone");
    ["dragenter", "dragover"].forEach((t) => dz.addEventListener(t, (e) => { e.preventDefault(); dz.classList.add("over"); }));
    ["dragleave", "drop"].forEach((t) => dz.addEventListener(t, (e) => { e.preventDefault(); dz.classList.remove("over"); }));
    dz.addEventListener("drop", (e) => pickFile(e.dataTransfer.files[0]));
    $("uploadForm").addEventListener("submit", upload);
    $("tokenForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const t = $("tokenInput").value.trim();
      if (!t) return;
      state.token = t;
      sessionStorage.setItem("enfactum_ai_token", t);
      $("tokenInput").value = "";
      $("tokenModal").classList.add("hidden");
      loadIdentity();
    });
    $("menuBtn").addEventListener("click", () => $("app").classList.add("nav-open"));
    $("scrim").addEventListener("click", closeNav);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { $("docsDrawer").classList.add("hidden"); closeNav(); }
    });
  }

  init();
})();
