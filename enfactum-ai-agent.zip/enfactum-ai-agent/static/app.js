(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = window.Markdown.escape;

  const ICONS = {
    auto: '<svg viewBox="0 0 24 24"><path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/></svg>',
    general: '<svg viewBox="0 0 24 24"><path d="M9.5 3a5.5 5.5 0 0 0-3.2 10v2.5A1.5 1.5 0 0 0 7.8 17h8.4a1.5 1.5 0 0 0 1.5-1.5V13A5.5 5.5 0 0 0 14.5 3z"/><path d="M9 21h6"/></svg>',
    web: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
    company: '<svg viewBox="0 0 24 24"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-4h6v4M9 10h.01M15 10h.01M9 14h.01M15 14h.01"/></svg>',
    document: '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>',
    image: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>',
    os: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/></svg>',
    attachment: '<svg viewBox="0 0 24 24"><path d="M21.4 11.1l-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="M5 12l5 5 9-10"/></svg>',
    copy: '<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>',
    more: '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></svg>',
    pin: '<svg viewBox="0 0 24 24"><path d="M12 17v5M5 17h14l-2-4V6h1V3H6v3h1v7z"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    x: '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  };
  const MODES = [
    { id: "auto", label: "Auto", title: "Automatically choose the best source" },
    { id: "general", label: "General", title: "Answer from the model's own knowledge" },
    { id: "web", label: "Web", title: "Search the public web for current information" },
    { id: "company", label: "Company", title: "Enfactum documents and live OS data only" },
  ];
  const IMAGE_EXT = [".png", ".jpg", ".jpeg", ".webp", ".gif"];
  const PANEL_TITLES = { general: "General", personalization: "Personalization", history: "Chats & history",
    knowledge: "Knowledge base", account: "Account", about: "About" };

  const state = {
    config: null, me: null, prefs: {}, mode: "auto", conversationId: null, conversations: [],
    streaming: false, controller: null, pending: [], context: { used: 0, window: 0, estimated: false },
    token: sessionStorage.getItem("enfactum_ai_token") || "", menuConv: null,
  };

  // ------------------------------------------------------------------ API
  function headers(extra) {
    const h = Object.assign({}, extra || {});
    if (state.token) h.Authorization = "Bearer " + state.token;
    return h;
  }
  async function api(path, opts = {}) {
    const res = await fetch(path, Object.assign({}, opts, { headers: headers(opts.headers), credentials: "same-origin" }));
    if (res.status === 401 && state.config && state.config.auth_mode !== "demo") {
      showTokenModal();
      throw new Error("Please sign in.");
    }
    if (!res.ok) {
      let detail = res.statusText;
      try { detail = (await res.json()).detail || detail; } catch (_) { /* not JSON */ }
      throw new Error(typeof detail === "string" ? detail : "Request failed");
    }
    return res;
  }
  const getJSON = async (path) => (await api(path)).json();
  const sendJSON = async (path, method, body) =>
    (await api(path, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })).json();
  const imageCache = {};
  async function imageUrl(id) {
    if (!imageCache[id]) imageCache[id] = api(`/api/attachments/${encodeURIComponent(id)}/file`).then((r) => r.blob()).then(URL.createObjectURL);
    return imageCache[id];
  }

  // ------------------------------------------------------------------ helpers
  function toast(message, isError) {
    const el = document.createElement("div");
    el.className = "toast" + (isError ? " error" : "");
    el.textContent = message;
    $("toasts").appendChild(el);
    setTimeout(() => el.remove(), isError ? 7000 : 3500);
  }
  const initials = (name) => (name || "?").split(/\s+/).map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  const hostOf = (url) => { try { return new URL(url).hostname.replace(/^www\./, ""); } catch (_) { return ""; } };
  const extOf = (name) => (name.match(/\.[^.]+$/) || [""])[0].toLowerCase();
  const fmtSize = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB";
  const fmtTokens = (n) => n >= 1e6 ? (n / 1e6).toFixed(n % 1e6 ? 1 : 0) + "M" : n >= 1000 ? (n / 1000).toFixed(n >= 1e4 ? 0 : 1) + "k" : String(n);
  function scrollToBottom(force) {
    const t = $("thread");
    if (force || t.scrollHeight - t.scrollTop - t.clientHeight < 160) t.scrollTop = t.scrollHeight;
  }
  function greeting() {
    const h = new Date().getHours();
    const part = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
    const first = state.me ? state.me.user.name.split(" ")[0] : "";
    return first ? `${part}, ${first}` : part;
  }

  // ------------------------------------------------------------------ bootstrap
  async function init() {
    if (new URLSearchParams(location.search).get("embed") === "1") $("app").classList.add("embed");
    const hash = new URLSearchParams(location.hash.slice(1));
    if (hash.get("token")) {
      state.token = hash.get("token");
      sessionStorage.setItem("enfactum_ai_token", state.token);
      history.replaceState(null, "", location.pathname + location.search);
    }
    let configLoaded;
    const configReady = new Promise((resolve) => (configLoaded = resolve));
    window.addEventListener("message", async (e) => {
      if (!e.data || e.data.type !== "enfactum-ai-token") return;
      await configReady;
      if (e.origin !== location.origin && !(state.config.trusted_origins || []).includes(e.origin)) return;
      if (typeof e.data.token === "string" && e.data.token) {
        state.token = e.data.token;
        sessionStorage.setItem("enfactum_ai_token", state.token);
        loadIdentity();
      }
    });

    renderModes();
    bindEvents();
    try {
      state.config = await (await fetch("/api/config")).json();
    } catch (_) {
      toast("Cannot reach the assistant server.", true);
      return;
    }
    configLoaded();
    document.title = state.config.app_name;
    $("brandName").textContent = state.config.app_name.replace(/ Assistant$/, "");
    $("dropHint").textContent = `${state.config.supported_extensions.join(", ")} · max ${state.config.max_upload_mb} MB`;
    $("attachInput").accept = state.config.attachment_extensions.join(",");
    $("kbQuickInput").accept = state.config.supported_extensions.join(",");
    if (state.config.auth_mode !== "demo" && !state.token && !state.config.cookie_auth) {
      if (!$("app").classList.contains("embed")) showTokenModal();
      return;
    }
    await loadIdentity();
  }

  async function loadIdentity() {
    try {
      state.me = await getJSON("/api/me");
    } catch (e) {
      toast(e.message, true);
      return;
    }
    const u = state.me.user;
    state.prefs = state.me.settings || {};
    applyTheme(state.prefs.theme);
    $("userName").textContent = u.name;
    $("userRoles").textContent = u.roles.join(", ") || "employee";
    $("userAvatar").textContent = initials(u.name);
    $("greeting").textContent = greeting();
    $("attachKb").classList.toggle("hidden", !state.me.capabilities.documents_manage);
    state.context.window = state.me.model.context_window;
    if (!state.me.model.configured) toast("The AI model is not configured: set LLM_API_KEY in .env and restart the server.", true);
    newChat();
    loadConversations();
  }

  // ------------------------------------------------------------------ preferences
  function applyTheme(theme) {
    if (theme === "light" || theme === "dark") document.documentElement.setAttribute("data-theme", theme);
    else document.documentElement.removeAttribute("data-theme");
    localStorage.setItem("enfactum_ai_theme", theme || "system");
  }
  let saveTimer = null;
  function setPref(key, value) {
    state.prefs[key] = value;
    if (key === "theme") applyTheme(value);
    if (key === "show_context_meter") updateMeter();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try {
        state.prefs = await sendJSON("/api/settings", "PUT", state.prefs);
        $("savedHint").classList.remove("hidden");
        setTimeout(() => $("savedHint").classList.add("hidden"), 1500);
      } catch (e) { toast(e.message, true); }
    }, 350);
  }

  function renderModes() {
    const webOff = state.me && !state.me.capabilities.web_search;
    if (webOff && state.mode === "web") state.mode = "auto";
    $("modes").innerHTML = MODES.map((m) => {
      const disabled = m.id === "web" && webOff;
      return `<button type="button" role="radio" class="mode${state.mode === m.id ? " active" : ""}" data-mode="${m.id}"` +
        ` aria-checked="${state.mode === m.id}" title="${esc(disabled ? "Web search is not available for your account" : m.title)}"${disabled ? " disabled" : ""}>${ICONS[m.id]}<span>${m.label}</span></button>`;
    }).join("");
  }

  // ------------------------------------------------------------------ context meter
  function updateMeter() {
    const meter = $("ctxMeter");
    const show = state.prefs.show_context_meter !== false && state.context.window > 0;
    meter.classList.toggle("hidden", !show);
    if (!show) return;
    const pendingTokens = state.pending.filter((a) => a.status === "ready").reduce((s, a) => s + (a.tokens || 0), 0);
    const draft = Math.ceil($("input").value.length / 4);
    const used = state.context.used;
    const next = used + pendingTokens + draft;
    const pct = Math.min(100, (next / state.context.window) * 100);
    $("ctxRing").style.strokeDashoffset = String(94.25 * (1 - pct / 100));
    $("ctxLabel").textContent = pct < 1 && next > 0 ? "<1%" : `${Math.round(pct)}%`;
    meter.classList.toggle("warn", pct >= 70 && pct < 90);
    meter.classList.toggle("full", pct >= 90);
    const extra = pendingTokens + draft;
    $("ctxPop").innerHTML = `<b>Context window</b>` +
      `<span>${fmtTokens(used)} of ${fmtTokens(state.context.window)} tokens used${state.context.estimated ? " (estimated)" : ""}</span>` +
      `<div class="bar"><i style="width:${pct.toFixed(1)}%"></i></div>` +
      (extra ? `<small>+ ~${fmtTokens(extra)} in your next message and attachments</small>` : "") +
      `<small>Includes instructions, chat history, attachments and search results. Older messages are trimmed automatically when it fills up.</small>` +
      (pct >= 70 ? `<small class="tip">Start a new chat for the most accurate answers.</small>` : "");
  }

  // ------------------------------------------------------------------ conversations
  async function loadConversations() {
    try {
      state.conversations = (await getJSON("/api/conversations")).conversations;
      renderConversations();
    } catch (_) { /* surfaced elsewhere */ }
  }
  function renderConversations() {
    const q = $("convSearch").value.trim().toLowerCase();
    const list = state.conversations.filter((c) => !q || c.title.toLowerCase().includes(q));
    const el = $("convList");
    if (!list.length) {
      el.innerHTML = `<div class="conv-empty">${q ? "No matching chats" : "No conversations yet"}</div>`;
      return;
    }
    const item = (c) => `<div class="conv-item${c.id === state.conversationId ? " active" : ""}" data-id="${esc(c.id)}" role="button" tabindex="0">` +
      `<span>${esc(c.title)}</span><button class="more" type="button" data-more="${esc(c.id)}" aria-label="Options">${ICONS.more}</button></div>`;
    const pinned = list.filter((c) => c.pinned);
    const recent = list.filter((c) => !c.pinned);
    el.innerHTML = (pinned.length ? `<div class="conv-label">${ICONS.pin}Pinned</div>` + pinned.map(item).join("") : "") +
      (recent.length ? `<div class="conv-label">${ICONS.clock}${q ? "Results" : "Recent"}</div>` + recent.map(item).join("") : "");
  }

  function openConvMenu(id, anchor) {
    const conv = state.conversations.find((c) => c.id === id);
    if (!conv) return;
    state.menuConv = conv;
    const menu = $("convMenu");
    menu.querySelector('[data-act="pin"] span').textContent = conv.pinned ? "Unpin" : "Pin";
    menu.classList.remove("hidden");
    const r = anchor.getBoundingClientRect();
    menu.style.top = Math.min(r.bottom + 4, window.innerHeight - menu.offsetHeight - 8) + "px";
    menu.style.left = Math.min(r.left, window.innerWidth - menu.offsetWidth - 8) + "px";
    document.querySelectorAll(".conv-item.menu-open").forEach((x) => x.classList.remove("menu-open"));
    anchor.closest(".conv-item").classList.add("menu-open");
  }
  function closeMenus() {
    $("convMenu").classList.add("hidden");
    $("attachMenu").classList.add("hidden");
    $("attachBtn").classList.remove("open");
    document.querySelectorAll(".conv-item.menu-open").forEach((x) => x.classList.remove("menu-open"));
  }
  async function convAction(act) {
    const conv = state.menuConv;
    closeMenus();
    if (!conv) return;
    try {
      if (act === "pin") {
        await sendJSON(`/api/conversations/${encodeURIComponent(conv.id)}`, "PATCH", { pinned: !conv.pinned });
        loadConversations();
      } else if (act === "delete") {
        if (!confirm("Delete this conversation?")) return;
        await api(`/api/conversations/${encodeURIComponent(conv.id)}`, { method: "DELETE" });
        if (conv.id === state.conversationId) newChat();
        loadConversations();
      } else if (act === "rename") {
        startRename(conv);
      }
    } catch (e) { toast(e.message, true); }
  }
  function startRename(conv) {
    const row = $("convList").querySelector(`.conv-item[data-id="${CSS.escape(conv.id)}"]`);
    if (!row) return;
    const span = row.querySelector("span");
    const input = document.createElement("input");
    input.value = conv.title;
    input.maxLength = 120;
    span.replaceWith(input);
    input.focus();
    input.select();
    let done = false;
    const finish = async (save) => {
      if (done) return;
      done = true;
      const title = input.value.trim();
      if (save && title && title !== conv.title) {
        try {
          await sendJSON(`/api/conversations/${encodeURIComponent(conv.id)}`, "PATCH", { title });
          if (conv.id === state.conversationId) $("convTitle").textContent = title;
        } catch (e) { toast(e.message, true); }
      }
      loadConversations();
    };
    input.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") finish(true);
      if (e.key === "Escape") finish(false);
    });
    input.addEventListener("click", (e) => e.stopPropagation());
    input.addEventListener("blur", () => finish(true));
  }

  function newChat() {
    if (state.streaming) stop();
    state.conversationId = null;
    state.mode = state.prefs.default_mode || "auto";
    state.context.used = 0;
    state.context.estimated = false;
    clearPending(true);
    renderModes();
    updateMeter();
    $("messages").innerHTML = "";
    $("welcome").classList.remove("hidden");
    $("convTitle").textContent = "New chat";
    renderConversations();
    $("input").focus();
    closeNav();
  }

  async function openConversation(id) {
    if (state.streaming) stop();
    try {
      const conv = await getJSON(`/api/conversations/${encodeURIComponent(id)}`);
      state.conversationId = conv.id;
      clearPending(true);
      $("convTitle").textContent = conv.title;
      $("welcome").classList.add("hidden");
      $("messages").innerHTML = "";
      state.context.used = 0;
      for (const m of conv.messages) {
        if (m.role === "user") addUserMessage(m.content, (m.meta && m.meta.attachments) || []);
        else {
          const view = addAssistantMessage();
          view.text = m.content;
          view.finish(m.sources, m.meta);
          if (m.meta && m.meta.context) state.context = Object.assign({}, state.context, m.meta.context);
        }
      }
      updateMeter();
      renderConversations();
      scrollToBottom(true);
      closeNav();
    } catch (e) { toast(e.message, true); }
  }

  // ------------------------------------------------------------------ attachments
  function attChip(a, removable) {
    const el = document.createElement("div");
    el.className = "att" + (a.status === "error" ? " error" : "");
    const isImg = a.kind === "image";
    const sub = a.status === "uploading" ? "Uploading…" : a.status === "error" ? a.error || "Failed" :
      isImg ? "Image" : `${extOf(a.name).slice(1).toUpperCase() || "File"}${a.tokens ? " · ~" + fmtTokens(a.tokens) + " tokens" : ""}`;
    el.innerHTML = `<span class="att-icon">${a.status === "uploading" ? '<span class="spinner"></span>' : isImg ? ICONS.image : ICONS.document}</span>` +
      `<span class="att-meta"><b></b><small></small></span>` + (removable ? `<button type="button" class="att-x" aria-label="Remove">${ICONS.x}</button>` : "");
    el.querySelector("b").textContent = a.name;
    el.querySelector("small").textContent = sub;
    el.title = a.name;
    if (isImg && a.status !== "uploading") {
      const setImg = (src) => { el.querySelector(".att-icon").innerHTML = `<img alt="">`; el.querySelector("img").src = src; };
      if (a.previewUrl) setImg(a.previewUrl);
      else if (a.id) imageUrl(a.id).then(setImg).catch(() => {});
    }
    return el;
  }
  function renderPending() {
    const box = $("attChips");
    box.innerHTML = "";
    state.pending.forEach((a, i) => {
      const chip = attChip(a, true);
      chip.querySelector(".att-x").addEventListener("click", () => removePending(i));
      box.appendChild(chip);
    });
    box.classList.toggle("hidden", !state.pending.length);
    updateSendState();
    updateMeter();
  }
  async function addFiles(fileList) {
    const files = Array.from(fileList || []);
    const allowed = state.config.attachment_extensions;
    for (const file of files) {
      if (state.pending.length >= 10) { toast("Up to 10 attachments per message.", true); break; }
      const ext = extOf(file.name);
      if (!allowed.includes(ext)) { toast(`${file.name}: unsupported file type`, true); continue; }
      if (file.size > state.config.max_attachment_mb * 1048576) { toast(`${file.name}: larger than ${state.config.max_attachment_mb} MB`, true); continue; }
      const item = { name: file.name, kind: IMAGE_EXT.includes(ext) ? "image" : "document", status: "uploading",
        previewUrl: IMAGE_EXT.includes(ext) ? URL.createObjectURL(file) : null };
      state.pending.push(item);
      renderPending();
      const fd = new FormData();
      fd.append("file", file);
      fd.append("conversation_id", state.conversationId || "");
      api("/api/attachments", { method: "POST", body: fd }).then((r) => r.json()).then((res) => {
        Object.assign(item, res, { status: "ready" });
      }).catch((e) => {
        Object.assign(item, { status: "error", error: e.message });
      }).finally(renderPending);
    }
  }
  function removePending(i) {
    const [a] = state.pending.splice(i, 1);
    if (a && a.id) api(`/api/attachments/${encodeURIComponent(a.id)}`, { method: "DELETE" }).catch(() => {});
    renderPending();
  }
  function clearPending(deleteUploaded) {
    if (deleteUploaded) state.pending.forEach((a) => a.id && api(`/api/attachments/${encodeURIComponent(a.id)}`, { method: "DELETE" }).catch(() => {}));
    state.pending = [];
    renderPending();
  }

  // ------------------------------------------------------------------ messages
  function addUserMessage(text, atts) {
    const wrap = document.createElement("div");
    wrap.className = "msg-user-wrap";
    if (atts && atts.length) {
      const row = document.createElement("div");
      row.className = "msg-atts";
      atts.forEach((a) => row.appendChild(attChip(Object.assign({ status: "ready" }, a), false)));
      wrap.appendChild(row);
    }
    const el = document.createElement("div");
    el.className = "msg-user";
    el.textContent = text;
    wrap.appendChild(el);
    $("messages").appendChild(wrap);
  }

  function addAssistantMessage() {
    const root = document.createElement("div");
    root.className = "msg-ai";
    root.innerHTML = '<div class="welcome-logo ai-avatar">E</div><div class="msg-body"><div class="steps"></div>' +
      '<div class="typing"><i></i><i></i><i></i></div><div class="md"></div><div class="sources hidden"></div><div class="msg-actions hidden"></div></div>';
    $("messages").appendChild(root);
    const q = (s) => root.querySelector(s);
    const view = {
      root, text: "", steps: {}, pending: false,
      step(ev) {
        q(".typing").classList.add("hidden");
        if (ev.state === "running") {
          const s = document.createElement("div");
          s.className = "step";
          s.innerHTML = `<span class="dot"><span class="spinner"></span></span><span></span>`;
          s.lastChild.textContent = ev.label;
          q(".steps").appendChild(s);
          view.steps[ev.id] = s;
        } else if (view.steps[ev.id]) {
          view.steps[ev.id].classList.add("done");
          view.steps[ev.id].querySelector(".dot").innerHTML = ICONS.check;
        }
        scrollToBottom();
      },
      append(token) {
        view.text += token;
        q(".typing").classList.add("hidden");
        if (!view.pending) {
          view.pending = true;
          requestAnimationFrame(() => {
            view.pending = false;
            const md = q(".md");
            md.innerHTML = window.Markdown.render(view.text);
            md.classList.add("caret");
            scrollToBottom();
          });
        }
      },
      error(message) {
        q(".typing").classList.add("hidden");
        const e = document.createElement("div");
        e.className = "msg-error";
        e.textContent = message;
        q(".msg-body").insertBefore(e, q(".sources"));
      },
      finish(sources, meta) {
        q(".typing").classList.add("hidden");
        const md = q(".md");
        md.classList.remove("caret");
        md.innerHTML = window.Markdown.render(view.text);
        renderSources(q(".sources"), sources || []);
        const actions = q(".msg-actions");
        if (view.text) {
          const latency = meta && meta.latency_ms ? `${(meta.latency_ms / 1000).toFixed(1)}s` : "";
          actions.innerHTML = `<button type="button" data-act="copy" title="Copy answer">${ICONS.copy}Copy</button>` +
            (latency ? `<span>· ${latency}</span>` : "");
          actions.classList.remove("hidden");
          actions.querySelector('[data-act="copy"]').addEventListener("click", () => {
            navigator.clipboard.writeText(view.text.replace(/\[(\d{1,3})\]/g, "")).then(() => toast("Copied"));
          });
        }
      },
    };
    return view;
  }

  function renderSources(el, sources) {
    if (!sources.length) return;
    el.innerHTML = '<div class="sources-title">Sources</div><div class="source-grid"></div>';
    const grid = el.lastChild;
    for (const s of sources) {
      const isLink = s.url && /^https?:\/\//.test(s.url);
      const card = document.createElement(isLink ? "a" : "div");
      card.className = "source";
      card.dataset.n = s.n;
      if (isLink) { card.href = s.url; card.target = "_blank"; card.rel = "noopener noreferrer"; }
      const icon = s.type === "web" ? ICONS.web : s.type === "os" ? ICONS.os : s.type === "attachment" ? ICONS.attachment : ICONS.document;
      const sub = s.type === "web" ? hostOf(s.url) : s.type === "os" ? "Enfactum OS · live data" :
        s.type === "attachment" ? "Your attachment" : "Company document";
      card.innerHTML = `<span class="num">${Number(s.n)}</span><span class="s-body"><strong></strong><small>${icon}<span></span></small></span>`;
      card.querySelector("strong").textContent = s.title;
      card.querySelector("small span").textContent = sub;
      if (s.snippet) card.title = s.snippet;
      grid.appendChild(card);
    }
    el.classList.remove("hidden");
  }

  // ------------------------------------------------------------------ chat
  async function send(text) {
    text = (text || "").trim();
    if (!text || state.streaming) return;
    if (state.pending.some((a) => a.status === "uploading")) { toast("Wait for attachments to finish uploading."); return; }
    const atts = state.pending.filter((a) => a.status === "ready");
    $("welcome").classList.add("hidden");
    $("input").value = "";
    autosize();
    addUserMessage(text, atts);
    state.pending = [];
    renderPending();
    const view = addAssistantMessage();
    scrollToBottom(true);
    setStreaming(true);
    state.controller = new AbortController();
    let sources = [], meta = {};
    try {
      const res = await api("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, conversation_id: state.conversationId, mode: state.mode,
          attachment_ids: atts.map((a) => a.id) }),
        signal: state.controller.signal,
      });
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx;
        while ((idx = buffer.indexOf("\n\n")) >= 0) {
          const raw = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          const line = raw.split("\n").find((l) => l.startsWith("data: "));
          if (!line) continue;
          const ev = JSON.parse(line.slice(6));
          if (ev.type === "conversation") {
            const isNew = !state.conversationId;
            state.conversationId = ev.id;
            if (isNew) { $("convTitle").textContent = text.length > 60 ? text.slice(0, 60) + "…" : text; loadConversations(); }
          } else if (ev.type === "token") view.append(ev.text);
          else if (ev.type === "status") view.step(ev);
          else if (ev.type === "usage") { state.context = { used: ev.used, window: ev.window, estimated: ev.estimated }; updateMeter(); }
          else if (ev.type === "sources") sources = ev.sources;
          else if (ev.type === "error") view.error(ev.message);
          else if (ev.type === "done") meta = ev;
        }
      }
    } catch (e) {
      if (e.name !== "AbortError") view.error(e.message || "Connection lost.");
    } finally {
      view.finish(sources, meta);
      setStreaming(false);
      loadConversations();
    }
  }
  function stop() { if (state.controller) state.controller.abort(); }
  function setStreaming(on) {
    state.streaming = on;
    $("sendBtn").classList.toggle("stop", on);
    $("sendBtn").setAttribute("aria-label", on ? "Stop" : "Send");
    updateSendState();
  }
  function updateSendState() {
    const uploading = state.pending.some((a) => a.status === "uploading");
    $("sendBtn").disabled = !state.streaming && (!$("input").value.trim() || uploading);
  }
  function autosize() {
    const t = $("input");
    t.style.height = "auto";
    t.style.height = Math.min(t.scrollHeight, 220) + "px";
    updateSendState();
    updateMeter();
  }

  // ------------------------------------------------------------------ settings
  function openSettings(tab) {
    $("settingsModal").classList.remove("hidden");
    showTab(tab || "general");
    closeNav();
  }
  function closeSettings() { $("settingsModal").classList.add("hidden"); }
  function showTab(tab) {
    document.querySelectorAll("#settingsNav button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
    document.querySelectorAll(".panel").forEach((p) => p.classList.toggle("hidden", p.dataset.panel !== tab));
    $("settingsPanelTitle").textContent = PANEL_TITLES[tab];
    syncPrefControls();
    if (tab === "knowledge") loadDocs();
    if (tab === "history") renderHistoryStats();
    if (tab === "account") renderAccount();
    if (tab === "about") renderAbout();
  }
  function syncPrefControls() {
    document.querySelectorAll("[data-pref]").forEach((el) => {
      const v = state.prefs[el.dataset.pref];
      if (el.classList.contains("seg")) el.querySelectorAll("button").forEach((b) => b.classList.toggle("active", b.dataset.v === v));
      else if (el.type === "checkbox") el.checked = v !== false;
      else if (document.activeElement !== el) el.value = v == null ? "" : v;
    });
  }
  function renderHistoryStats() {
    const total = state.conversations.length;
    const pinned = state.conversations.filter((c) => c.pinned).length;
    const week = state.conversations.filter((c) => Date.now() / 1000 - c.updated_at < 7 * 86400).length;
    $("historyStats").innerHTML = [[total, "Conversations"], [pinned, "Pinned"], [week, "Active this week"]]
      .map(([n, l]) => `<div class="stat"><b>${n}</b><small>${l}</small></div>`).join("");
  }
  function renderAccount() {
    const u = state.me.user;
    $("accAvatar").textContent = initials(u.name);
    $("accName").textContent = u.name;
    $("accEmail").textContent = u.email || "";
    $("accRoles").innerHTML = (u.roles.length ? u.roles : ["employee"]).map((r) => `<span class="chip">${esc(r)}</span>`).join("");
    const c = state.me.capabilities;
    const access = ["Company documents"].concat(c.web_search ? ["Web search"] : [], c.os_tools, c.documents_manage ? ["Manage knowledge base"] : []);
    $("accAccess").innerHTML = access.map((r) => `<span class="chip">${esc(r)}</span>`).join("");
    $("signOutRow").classList.toggle("hidden", !state.token);
  }
  function renderAbout() {
    const m = state.me.model;
    const rows = [["Version", state.me.version], ["AI provider", m.provider], ["Model", m.name],
      ["Context window", fmtTokens(m.context_window) + " tokens"], ["Image understanding", m.vision ? "Enabled" : "Disabled"],
      ["Sign-in", state.config.auth_mode === "demo" ? "Local test mode" : "Enfactum OS"]];
    $("aboutList").innerHTML = rows.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(String(v))}</dd>`).join("");
  }
  async function testLlm() {
    const el = $("llmStatus");
    el.className = "";
    el.textContent = "Testing…";
    try {
      const r = await getJSON("/api/health/llm");
      el.textContent = r.ok ? "Connected. The model responded successfully." : r.error;
      el.className = r.ok ? "ok" : "bad";
    } catch (e) { el.textContent = e.message; el.className = "bad"; }
  }
  async function exportChats() {
    try {
      const blob = await (await api("/api/export")).blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "enfactum-ai-chats.json";
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch (e) { toast(e.message, true); }
  }
  async function deleteAllChats() {
    if (!confirm("Delete ALL your conversations? This cannot be undone.")) return;
    try {
      const r = await sendJSON("/api/conversations", "DELETE", {});
      toast(`Deleted ${r.deleted} conversation(s)`);
      newChat();
      await loadConversations();
      renderHistoryStats();
    } catch (e) { toast(e.message, true); }
  }

  // ------------------------------------------------------------------ knowledge base
  async function loadDocs() {
    const list = $("docList");
    list.innerHTML = '<div class="empty">Loading…</div>';
    try {
      const data = await getJSON("/api/documents");
      $("uploadForm").classList.toggle("hidden", !data.can_manage);
      if (!data.documents.length) { list.innerHTML = '<div class="empty">No documents available to you yet.</div>'; return; }
      list.innerHTML = "";
      for (const d of data.documents) {
        const row = document.createElement("div");
        row.className = "doc";
        const restricted = d.visibility && d.visibility.scope === "restricted";
        row.innerHTML = `<div class="doc-icon">${ICONS.document}</div><div class="doc-meta"><strong></strong>` +
          `<small>${esc(d.filename)} · ${fmtSize(d.size_bytes)} · ${d.chunk_count} sections</small>` +
          (restricted ? `<span class="badge lock" title="Visible to: ${esc((d.visibility.roles || []).join(", "))}">Restricted</span>` : "") +
          `</div>` + (data.can_manage ? `<button class="icon-btn" type="button" aria-label="Delete">${ICONS.trash}</button>` : "");
        row.querySelector("strong").textContent = d.title;
        const del = row.querySelector("button");
        if (del) del.addEventListener("click", () => deleteDoc(d));
        list.appendChild(row);
      }
    } catch (e) { list.innerHTML = ""; toast(e.message, true); }
  }
  async function deleteDoc(d) {
    if (!confirm(`Remove “${d.title}” from the knowledge base?`)) return;
    try {
      await api(`/api/documents/${encodeURIComponent(d.id)}`, { method: "DELETE" });
      toast("Document removed");
      loadDocs();
    } catch (e) { toast(e.message, true); }
  }
  let kbFile = null;
  function pickKbFile(file) {
    kbFile = file || null;
    $("dropText").textContent = file ? file.name : "Drop a file or browse";
    $("uploadBtn").disabled = !file;
  }
  async function uploadKb(e) {
    e.preventDefault();
    if (!kbFile) return;
    const fd = new FormData();
    fd.append("file", kbFile);
    fd.append("title", $("docTitle").value.trim());
    fd.append("visibility", $("docVisibility").value);
    fd.append("roles", $("docRoles").value.trim());
    const btn = $("uploadBtn");
    btn.disabled = true;
    btn.textContent = "Indexing…";
    try {
      const r = await (await api("/api/documents", { method: "POST", body: fd })).json();
      toast(`Added “${r.title}” to the knowledge base (${r.chunks} sections)`);
      $("uploadForm").reset();
      $("docRoles").classList.add("hidden");
      pickKbFile(null);
      loadDocs();
    } catch (err) { toast(err.message, true); btn.disabled = false; }
    finally { btn.textContent = "Upload & index"; }
  }

  // ------------------------------------------------------------------ misc
  function showTokenModal() { $("tokenModal").classList.remove("hidden"); $("tokenInput").focus(); }
  function closeNav() { $("app").classList.remove("nav-open"); }

  function bindEvents() {
    $("composer").addEventListener("submit", (e) => { e.preventDefault(); state.streaming ? stop() : send($("input").value); });
    $("input").addEventListener("input", autosize);
    $("input").addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || e.isComposing) return;
      const enterSends = state.prefs.enter_to_send !== false;
      if ((enterSends && !e.shiftKey) || (!enterSends && (e.ctrlKey || e.metaKey))) {
        e.preventDefault();
        if (!state.streaming) send($("input").value);
      }
    });
    $("input").addEventListener("paste", (e) => {
      const files = Array.from(e.clipboardData && e.clipboardData.files || []);
      if (files.length) { e.preventDefault(); addFiles(files); }
    });
    const composer = $("composer");
    let dragDepth = 0;
    $("main").addEventListener("dragenter", (e) => { if (e.dataTransfer.types.includes("Files")) { dragDepth++; composer.classList.add("dragging"); } });
    $("main").addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; composer.classList.remove("dragging"); } });
    $("main").addEventListener("dragover", (e) => e.preventDefault());
    $("main").addEventListener("drop", (e) => {
      e.preventDefault();
      dragDepth = 0;
      composer.classList.remove("dragging");
      if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
    });

    $("attachBtn").addEventListener("click", (e) => {
      e.stopPropagation();
      if (!state.me || !state.me.capabilities.documents_manage) { $("attachInput").click(); return; }
      const open = $("attachMenu").classList.contains("hidden");
      closeMenus();
      if (open) { $("attachMenu").classList.remove("hidden"); $("attachBtn").classList.add("open"); }
    });
    $("attachChat").addEventListener("click", () => { closeMenus(); $("attachInput").click(); });
    $("attachKb").addEventListener("click", () => { closeMenus(); $("kbQuickInput").click(); });
    $("attachInput").addEventListener("change", (e) => { addFiles(e.target.files); e.target.value = ""; });
    $("kbQuickInput").addEventListener("change", (e) => {
      const f = e.target.files[0];
      e.target.value = "";
      if (!f) return;
      openSettings("knowledge");
      pickKbFile(f);
      $("docTitle").focus();
    });

    $("modes").addEventListener("click", (e) => {
      const b = e.target.closest(".mode");
      if (!b || b.disabled) return;
      state.mode = b.dataset.mode;
      renderModes();
      $("input").focus();
    });
    $("newChat").addEventListener("click", newChat);
    $("convSearch").addEventListener("input", renderConversations);
    $("convList").addEventListener("click", (e) => {
      const more = e.target.closest("[data-more]");
      if (more) { e.stopPropagation(); openConvMenu(more.dataset.more, more); return; }
      const item = e.target.closest(".conv-item");
      if (item && !item.querySelector("input")) openConversation(item.dataset.id);
    });
    $("convList").addEventListener("keydown", (e) => {
      const item = e.target.closest(".conv-item");
      if (item && e.key === "Enter" && e.target === item) openConversation(item.dataset.id);
    });
    $("convMenu").addEventListener("click", (e) => { const b = e.target.closest("[data-act]"); if (b) convAction(b.dataset.act); });
    document.addEventListener("click", (e) => { if (!e.target.closest(".menu")) closeMenus(); });
    $("convList").addEventListener("scroll", closeMenus);

    $("messages").addEventListener("click", (e) => {
      const cite = e.target.closest(".cite");
      if (cite) {
        const card = cite.closest(".msg-body").querySelector(`.source[data-n="${cite.dataset.n}"]`);
        if (card) {
          card.scrollIntoView({ behavior: "smooth", block: "nearest" });
          card.classList.add("flash");
          setTimeout(() => card.classList.remove("flash"), 1400);
        }
        return;
      }
      const copy = e.target.closest(".copy-code");
      if (copy) {
        navigator.clipboard.writeText(copy.closest(".code").querySelector("code").textContent)
          .then(() => { copy.textContent = "Copied"; setTimeout(() => (copy.textContent = "Copy"), 1200); });
      }
    });

    // settings
    $("openSettings").addEventListener("click", () => openSettings("general"));
    $("openKb").addEventListener("click", () => openSettings("knowledge"));
    $("userCard").addEventListener("click", () => openSettings("account"));
    $("closeSettings").addEventListener("click", closeSettings);
    $("settingsModal").addEventListener("click", (e) => { if (e.target.id === "settingsModal") closeSettings(); });
    $("settingsNav").addEventListener("click", (e) => { const b = e.target.closest("[data-tab]"); if (b) showTab(b.dataset.tab); });
    document.querySelectorAll(".seg[data-pref]").forEach((seg) => seg.addEventListener("click", (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      setPref(seg.dataset.pref, b.dataset.v);
      syncPrefControls();
    }));
    document.querySelectorAll("select[data-pref], input[type=checkbox][data-pref]").forEach((el) =>
      el.addEventListener("change", () => setPref(el.dataset.pref, el.type === "checkbox" ? el.checked : el.value)));
    document.querySelectorAll("textarea[data-pref]").forEach((el) => el.addEventListener("input", () => setPref(el.dataset.pref, el.value)));
    $("exportChats").addEventListener("click", exportChats);
    $("deleteAllChats").addEventListener("click", deleteAllChats);
    $("testLlm").addEventListener("click", testLlm);
    $("signOut").addEventListener("click", () => {
      sessionStorage.removeItem("enfactum_ai_token");
      state.token = "";
      location.reload();
    });

    // knowledge base upload
    $("docVisibility").addEventListener("change", (e) => $("docRoles").classList.toggle("hidden", e.target.value !== "restricted"));
    $("fileInput").addEventListener("change", (e) => pickKbFile(e.target.files[0]));
    const dz = $("dropzone");
    ["dragenter", "dragover"].forEach((t) => dz.addEventListener(t, (e) => { e.preventDefault(); dz.classList.add("over"); }));
    ["dragleave", "drop"].forEach((t) => dz.addEventListener(t, (e) => { e.preventDefault(); dz.classList.remove("over"); }));
    dz.addEventListener("drop", (e) => pickKbFile(e.dataTransfer.files[0]));
    $("uploadForm").addEventListener("submit", uploadKb);

    $("tokenForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const t = $("tokenInput").value.trim();
      if (!t) return;
      state.token = t;
      sessionStorage.setItem("enfactum_ai_token", t);
      $("tokenInput").value = "";
      $("tokenModal").classList.add("hidden");
      loadIdentity();
    });
    $("menuBtn").addEventListener("click", () => $("app").classList.add("nav-open"));
    $("scrim").addEventListener("click", closeNav);
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { closeMenus(); closeSettings(); closeNav(); }
    });
  }

  init();
})();
