# Integrating with Enfactum OS

The assistant is a separate service. Integration needs **no changes to Enfactum OS business logic**, only three things the OS already has or can expose with minimal effort:

1. A way to identify the user (Sanctum token, session cookie, or a signed JWT).
2. An endpoint that returns the user's roles and permissions.
3. Existing read-only API endpoints for the data the assistant should be able to look up.

> This repository was built without access to the Enfactum OS source. Nothing below assumes specific Enfactum routes, models or permission names. Before go-live, complete the checklist in section 5 against the real code and fill in `config/os_tools.yaml` from `php artisan route:list`.

---

## 1. Authentication

### Option A: Sanctum bearer token (recommended, `AUTH_MODE=laravel`)

The assistant calls `GET {OS_BASE_URL}{OS_USER_ENDPOINT}` with the caller's `Authorization: Bearer …` header and maps the JSON through the `OS_USER_*_FIELD` settings.

Laravel's default `routes/api.php` often contains:

```php
Route::middleware('auth:sanctum')->get('/user', fn (Request $r) => $r->user());
```

This returns the user but usually **not** their roles/permissions. If Enfactum uses `spatie/laravel-permission`, a dedicated read-only endpoint is the least invasive fix (it adds a route, and changes none):

```php
// routes/api.php
Route::middleware('auth:sanctum')->get('/ai/me', function (Request $request) {
    $u = $request->user();
    return [
        'id'          => $u->id,
        'name'        => $u->name,
        'email'       => $u->email,
        'roles'       => $u->getRoleNames(),                          // ["hr_manager", ...]
        'permissions' => $u->getAllPermissions()->pluck('name'),      // ["employees.view", ...]
    ];
});
```

```env
AUTH_MODE=laravel
OS_BASE_URL=https://os.enfactum.example
OS_USER_ENDPOINT=/api/ai/me
```

If the payload is wrapped (e.g. `{"data": {...}}`), use dot-paths: `OS_USER_ROLES_FIELD=data.roles`.

The frontend obtains the token the way the OS already does (for example, a personal access token issued at login) and passes it to the assistant (see section 3).

### Option B: session cookies (Sanctum SPA / Filament)

Set `OS_FORWARD_COOKIES=true`. The browser's cookies are forwarded to the OS, which only works when the assistant is served on the **same site** as the OS (e.g. `assistant.enfactum.example` next to `os.enfactum.example`, with `SESSION_DOMAIN=.enfactum.example`). Add the assistant's domain to `SANCTUM_STATEFUL_DOMAINS`.

### Option C: signed JWT (`AUTH_MODE=jwt`)

The OS issues a short-lived JWT (≤ 15 min) containing `sub`, `name`, `email`, `roles`, `permissions`, signed with `JWT_SECRET` (HS256) or an RSA key (`JWT_PUBLIC_KEY_FILE`, `JWT_ALGORITHMS=RS256`). This is the fastest option (no identity round-trip), but OS tools still need a token the OS accepts. The JWT itself is forwarded, so the OS must accept it on the tool endpoints, or use Option A for tools.

---

## 2. Exposing live data as tools

Edit `config/os_tools.yaml`, then set `OS_TOOLS_FILE=config/os_tools.yaml` and `MOCK_OS_ENABLED=false`.

1. List candidate endpoints: `php artisan route:list --path=api --method=GET`.
2. Pick endpoints that already:
   - sit behind `auth:sanctum` (or the auth guard you use),
   - authorise with policies / `can:` middleware / scoped queries,
   - return an API Resource (so hidden attributes stay hidden).
3. Declare one tool per endpoint: a clear `description` (this is how the model decides when to call it), a JSON-Schema for parameters, and a minimal `response.fields` allow-list.
4. Set `required_permission` to the OS permission that guards the route, so the tool isn't even offered to users who can't use it.

If a module (for example Finance) has no suitable API yet, add a **read-only** endpoint in the OS that reuses the existing policy (`$this->authorize('viewAny', Invoice::class)`) and API Resource. Do not give the assistant a database connection.

Start the service: the log prints `Loaded N Enfactum OS tools`. Invalid YAML, non-GET methods or bad schemas stop startup with a clear error.

---

## 3. Embedding in the Enfactum OS frontend

### Option A: iframe (zero frontend build changes)

```tsx
// e.g. a floating panel or a route in the React app
<iframe
  src="https://assistant.enfactum.example/?embed=1"
  title="Enfactum AI"
  style={{ width: "100%", height: "100%", border: 0 }}
  onLoad={(e) => e.currentTarget.contentWindow?.postMessage(
    { type: "enfactum-ai-token", token: sanctumToken },
    "https://assistant.enfactum.example"
  )}
/>
```

- `?embed=1` hides the assistant's own sidebar.
- Add the OS origin to `CORS_ORIGINS`. It is also used for the iframe `frame-ancestors` policy and as the trusted origin for `postMessage`.

### Option B: native React component

Call the API directly and render the stream with your own design system:

```ts
const res = await fetch(`${ASSISTANT_URL}/api/chat`, {
  method: "POST",
  headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
  body: JSON.stringify({ message, conversation_id, mode: "auto" }),
});
const reader = res.body!.getReader();
const decoder = new TextDecoder();
let buf = "";
for (;;) {
  const { value, done } = await reader.read();
  if (done) break;
  buf += decoder.decode(value, { stream: true });
  let i;
  while ((i = buf.indexOf("\n\n")) >= 0) {
    const ev = JSON.parse(buf.slice(6, i));          // strip "data: "
    buf = buf.slice(i + 2);
    // ev.type: conversation | status | token | sources | done | error
  }
}
```

Serve the assistant on its own (sub)domain: the bundled UI uses root-relative paths (`/api`, `/static`).

---

## 4. Assistant permissions to create in the OS (optional)

| Setting | Suggested permission | Effect |
|---|---|---|
| `PERM_CHAT` | `ai.use` | Who can use the assistant at all (empty = every authenticated user) |
| `PERM_WEB_SEARCH` | `ai.web_search` | Who may trigger web searches |
| `PERM_DOCUMENTS_MANAGE` | `ai.documents.manage` | Who may upload/delete knowledge-base documents |
| `ADMIN_ROLES` | `super_admin,admin` | Roles that see every document and pass every assistant check |

Document visibility uses OS **role names**. Restrict a document to `hr_manager` and only users whose `/api/user` roles include `hr_manager` (or an admin role) will ever retrieve it.

---

## 5. Go-live checklist against the real Enfactum OS source

Complete this with the real repository before production (this is the "AI engineering overview" analysis):

- [ ] **Auth guard(s):** Sanctum tokens, SPA cookies, Filament panel guard? Which does the React app use for `/api`?
- [ ] **RBAC:** spatie/laravel-permission, Filament Shield, custom gates? Exact role/permission names, super-admin bypass (`Gate::before`).
- [ ] **Identity endpoint:** existing route returning roles + permissions, or add `/api/ai/me` (section 1).
- [ ] **Per-module read endpoints** (employees, projects, clients/CRM, contracts, vendors, finance, documents): route, policy, API Resource, filterable query params.
- [ ] **Sensitive fields per model** (`$hidden`, Resource fields): salary, bank details, personal IDs. Confirm the API already hides them for unauthorised roles.
- [ ] **Row-level rules** (global scopes, policy `view` checks): confirm they apply on the API routes, not only in Filament resources.
- [ ] **Static knowledge** to upload: policies, handbooks, SOPs, with their intended audience (role list).
- [ ] **CORS / session domain** settings for the chosen embedding option.
- [ ] Assistant settings: `ENVIRONMENT=production`, demo off, see `docs/SECURITY.md`.
