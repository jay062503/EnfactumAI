# From knowledge assistant to agentic AI

## Where it is today

The assistant is already a **read-only agent**, not just retrieval. For each question it:

1. decides which sources it needs (LLM, web, documents, attachments, OS tools, DB templates),
2. calls several tools in parallel,
3. reads the results and calls more tools if needed (up to `MAX_TOOL_ROUNDS`, default 5),
4. writes a cited answer.

What it deliberately cannot do yet is **act**: create, update or send anything in Enfactum OS or elsewhere.

## What "agentic" adds

| Capability | Example | Needed |
|---|---|---|
| Actions (write tools) | "Apply for leave 12–14 Nov", "Create a task for Sara", "Draft and send the client update" | Write tools + confirmation step |
| Multi-step tasks | "Prepare the monthly delivery report for all my projects" | Planner, longer tool loop, progress UI |
| Background jobs | "Every Monday, email me overdue invoices" | Scheduler/queue, stored task definitions |
| Memory | Remembers the employee's recurring context across chats | Per-user memory store with review/delete |
| Workflows / hand-offs | Route a request to approval, wait, continue | Durable state machine |

## How to add it safely (fits the current architecture)

**1. Write tools reuse Laravel.** Add `method: POST|PUT|PATCH` support to a separate `ActionTool` class. The request is sent to an existing OS endpoint with the employee's token, so Laravel validation, policies and events (notifications, audit) run exactly as if the employee clicked the button.

**2. A human confirms every action.** The agent never executes a write directly:

```text
LLM proposes action ─► server validates args (JSON Schema + OS dry-run if available)
                     ─► UI shows a confirmation card: "Apply for leave 12–14 Nov (3 days)?"  [Confirm] [Edit] [Cancel]
                     ─► on Confirm: server executes with the user's token, streams the result
```

New SSE event types for this: `action_proposed`, `action_result`. There is one server-side table of pending actions per user, with expiry.

**3. Permissions stay layered.** Each action has a `required_permission`, a feature flag (`AI_ACTIONS_ENABLED`), and OS-side authorisation on execution. Start with low-risk, reversible actions (drafts, tasks, leave requests). Leave payments and deletions for last, or never.

**4. Planning for longer tasks.** Raise `MAX_TOOL_ROUNDS` for a "Task" mode and show the plan and progress steps in the UI (the `status` events already support this). For jobs that outlive a request, move execution to a worker queue (Redis + RQ/Celery, or Laravel queues through an OS endpoint).

**5. Memory.** Store short, user-approved facts ("I manage the Northwind account") in a per-user table and inject them like the Personalization settings. Employees can view and delete them in Settings.

**6. Guardrails.**
- Every action is logged in `audit_log`.
- Actions are rate-limited per user.
- Tool results can never trigger actions without the user's confirmation.
- An action cannot be proposed from content that came only from documents or web pages (prompt-injection defence).

## Suggested order

1. Confirmation framework + 2–3 low-risk actions (create task, draft email, leave request).
2. Task mode with visible plan and progress.
3. Scheduled and background tasks.
4. Memory.
5. Approval workflows.

Each step is additive: none of it changes the existing read-only path or its security guarantees.
