# Security model

The central rule: **the assistant never has more access than the employee using it.** Enfactum OS stays the only authority on who may see what.

## Mandatory constraints and how they are enforced

| # | Constraint | Enforcement |
|---|---|---|
| 1 | AI must not bypass existing authorization | OS tools call existing OS endpoints, so Laravel middleware, policies, gates and scopes run unchanged. The assistant has no service account and no DB connection to Enfactum OS. |
| 2 | AI inherits the authenticated user's permissions | `AuthService` resolves identity from the OS on every request (60 s cache). The user's own token/cookies are forwarded on every OS tool call (`app/tools/os_api.py`). |
| 3 | No unrestricted database access | The assistant only talks to its own SQLite store (documents, chats, audit), always with parameterised queries. Enfactum data is reachable only through declared OS endpoints. |
| 4 | No LLM-generated SQL | No SQL tool exists. Tool arguments are validated against a JSON Schema and sent as URL query/path parameters (URL-encoded) to fixed, admin-declared paths. |
| 5 | Company-data tools are read-only | `OSApiTool` refuses any method other than `GET` at startup, and absolute URLs are rejected. |
| 6 | Sensitive fields filtered by permission | The OS filters by permission first (API Resources / policies). The assistant then applies a per-tool `response.fields` allow-list and always redacts secret-like keys (password, token, api_key, …). Documents carry role-based `visibility`, applied **before** ranking so restricted text never reaches the model. |
| 7 | Retrieved content is untrusted data | Every tool result is wrapped in `<tool_result>` with an explicit "data, not instructions" notice, and the system prompt forbids following embedded instructions. Only tools already authorised for the user can be called, so injected instructions cannot escalate. |
| 8 | Credentials never exposed to the LLM or frontend | `UserContext.os_token` is excluded from `repr` and `public()` and never placed in prompts. LLM, embedding and search keys live only in server env vars. Error messages returned to the model are generic. |
| 9 | Write operations only via explicit, confirmed tools | Not implemented, by design. Adding one requires a new tool class with server-side validation, an explicit permission, and a user-confirmation step in the UI before execution. |
| 10 | Existing Enfactum OS functionality not broken | The assistant is a separate service. The only OS-side requirements are CORS/embedding settings and, if missing, a `/api/user` endpoint that returns roles and permissions. |

## Defence in depth

- **Tool exposure:** tools whose `required_permission` the user lacks are never sent to the LLM. Calls to unknown or unoffered tools are refused and audited (`tool_denied`).
- **Row-level security:** comes free from the OS. For example, the mock OS returns only the projects a user belongs to, without the assistant knowing that rule.
- **Conversation isolation:** every conversation query filters by `user_id`.
- **Rate limiting:** per user (`RATE_LIMIT_PER_MINUTE`).
- **Uploads:** extension allow-list, size limit, parsed server-side (no macros executed), and only users with `PERM_DOCUMENTS_MANAGE` can upload.
- **Browser:** HTML-escaping Markdown renderer (no raw HTML), a CSP without inline scripts, `nosniff`, `no-referrer`, and restricted `frame-ancestors`.
- **Production guard:** `ENVIRONMENT=production` refuses to start with `AUTH_MODE=demo`, and `/api/docs` is disabled.
- **Audit:** tool calls (name and arguments), uploads and deletions are recorded in `audit_log`.

## Deployment checklist

- [ ] `ENVIRONMENT=production`, `AUTH_MODE=laravel` or `jwt`
- [ ] `MOCK_OS_ENABLED=false`, `SEED_SAMPLE_DOCS=false`, demo documents deleted
- [ ] HTTPS in front of the service; `OS_VERIFY_SSL=true`
- [ ] `CORS_ORIGINS` limited to the Enfactum OS origin(s)
- [ ] `config/os_tools.yaml` reviewed: only real, read-only endpoints, minimal `fields`
- [ ] LLM provider data-processing terms approved, or a self-hosted model used
- [ ] `DATA_DIR` on an encrypted, backed-up volume
