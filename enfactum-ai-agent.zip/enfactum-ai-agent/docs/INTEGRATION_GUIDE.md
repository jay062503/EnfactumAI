# Enfactum AI Assistant: Complete Integration Guide

This guide takes the assistant from a local test to a production integration with **Enfactum OS** (Laravel / Filament / React / PostgreSQL). It covers the OS itself, live company data (APIs and databases), and company knowledge (documents).

> The assistant was built without access to the Enfactum OS source. Wherever this guide shows Laravel code, adapt route names, models and permission names to the real codebase (`php artisan route:list`, `app/Models`, `app/Policies`).

## Contents

1. [How the pieces fit](#1-how-the-pieces-fit)
2. [Run it locally](#2-run-it-locally)
3. [Choose and configure the AI model](#3-choose-and-configure-the-ai-model)
4. [Connect employee sign-in (authentication)](#4-connect-employee-sign-in-authentication)
5. [Map roles and permissions (RBAC)](#5-map-roles-and-permissions-rbac)
6. [Connect live company data](#6-connect-live-company-data)
7. [Load company knowledge (documents)](#7-load-company-knowledge-documents)
8. [Embed the assistant in Enfactum OS](#8-embed-the-assistant-in-enfactum-os)
9. [Deploy to production](#9-deploy-to-production)
10. [Test the integration](#10-test-the-integration)
11. [Troubleshooting](#11-troubleshooting)
12. [Reference](#12-reference)

---

## 1. How the pieces fit

```text
Employee (browser, already signed in to Enfactum OS)
   │  token or session cookie
   ▼
Enfactum AI Assistant (this service, FastAPI)
   ├─ Who is this?   → asks Enfactum OS  GET /api/...me  → id, roles, permissions
   ├─ General knowledge  → LLM directly
   ├─ Public / current   → web search
   ├─ Company knowledge  → knowledge base (uploaded documents, filtered by role)
   ├─ Chat attachments   → files/images the employee attached to this chat
   └─ Live company data
         ├─ A. Enfactum OS API tools  (recommended: call existing APIs with the EMPLOYEE's token)
         └─ B. Read-only DB templates (only when no API exists; admin-written SQL)
```

**Golden rule:** the assistant never has more access than the employee using it. Enfactum OS remains the authority for identity, roles, permissions and row-level rules.

---

## 2. Run it locally

```bash
cd enfactum-ai-agent
cp .env.example .env            # the server reads ONLY .env
# edit .env → LLM_API_KEY=...
./run.sh                        # Windows: run.bat    Docker: docker compose up -d --build
```

Open <http://localhost:8080>. Demo mode signs you in as a single test employee against a bundled mock OS, with three sample policies (one HR-only, hidden from this employee). Use it to confirm the model, search and UI work before connecting the real OS.

Then open **Settings → About → Test connection**. It should report "Connected".

---

## 3. Choose and configure the AI model

Only `LLM_API_KEY` is required. The provider is detected from the key prefix:

| Key prefix | Provider | Default model | Embeddings |
|---|---|---|---|
| `sk-` / `sk-proj-` | OpenAI | gpt-4o-mini | yes |
| `AIza` | Google Gemini | gemini-2.0-flash | yes |
| `gsk_` | Groq | llama-3.3-70b-versatile | keyword search |
| `sk-or-` | OpenRouter | openai/gpt-4o-mini | keyword search |
| `sk-ant-` | Anthropic | claude-3-5-haiku-latest | keyword search |

Override with `LLM_PROVIDER`, `LLM_MODEL`, `LLM_BASE_URL`. For a model that stays inside your network:

```env
LLM_PROVIDER=ollama
LLM_BASE_URL=http://localhost:11434/v1
LLM_MODEL=qwen2.5:14b          # must support tool calling
EMBEDDING_PROVIDER=local       # pip install -r requirements-optional.txt
LLM_SUPPORTS_VISION=false      # unless the model reads images
```

Requirements:

- The model must support **tool/function calling**.
- Set `LLM_CONTEXT_WINDOW` if the model differs from the provider default. It drives the UI context meter and history trimming.
- Providers without an embeddings API fall back to keyword search automatically. Set `EMBEDDING_PROVIDER=local` for semantic search with no API.

For accuracy, use `gpt-4o`/`gpt-4.1` class models. For speed and cost, use `gpt-4o-mini`/`gemini-2.0-flash`.

---

## 4. Connect employee sign-in (authentication)

Pick **one** option. All three make the assistant see the same employee the OS sees.

### Option A: Sanctum token (recommended)

**4A.1 Add an identity endpoint to Enfactum OS** (read-only; changes nothing existing). With `spatie/laravel-permission`:

```php
// routes/api.php
use Illuminate\Http\Request;

Route::middleware('auth:sanctum')->get('/ai/me', function (Request $request) {
    $u = $request->user();
    return [
        'id'          => $u->id,
        'name'        => $u->name,
        'email'       => $u->email,
        'roles'       => $u->getRoleNames(),                       // ["employee", "hr_manager"]
        'permissions' => $u->getAllPermissions()->pluck('name'),   // ["employees.view", ...]
    ];
});
```

Without spatie, return whatever the OS uses (e.g. `$u->role->name`, `$u->permissions()->pluck('slug')`). Any shape works: map it with dot-paths in step 4A.3.

**4A.2 Give the frontend a token for the assistant.** Filament/React sessions usually use cookies, so issue a short-lived Sanctum token from the logged-in session:

```php
// routes/web.php  (session-authenticated)
Route::middleware(['web', 'auth'])->post('/ai/token', function (Request $request) {
    $user = $request->user();
    $user->tokens()->where('name', 'ai-assistant')->delete();          // one active token per user
    return ['token' => $user->createToken('ai-assistant', ['*'], now()->addHours(8))->plainTextToken];
});
```

(`createToken` with an expiry needs Sanctum 3.3+/4.x. On older versions, set `'expiration' => 480` in `config/sanctum.php`.)

**4A.3 Configure the assistant:**

```env
AUTH_MODE=laravel
OS_BASE_URL=https://os.enfactum.example
OS_USER_ENDPOINT=/api/ai/me
OS_USER_ID_FIELD=id
OS_USER_ROLES_FIELD=roles              # e.g. data.roles if wrapped
OS_USER_PERMISSIONS_FIELD=permissions
```

Identity is cached for `AUTH_CACHE_SECONDS` (default 60). A role change in the OS applies within a minute.

### Option B: shared session cookies (same parent domain)

Serve the assistant at e.g. `ai.enfactum.example` next to `os.enfactum.example`:

```env
# assistant .env
AUTH_MODE=laravel
OS_FORWARD_COOKIES=true
OS_USER_ENDPOINT=/api/ai/me
```

```env
# Enfactum OS .env
SESSION_DOMAIN=.enfactum.example
SANCTUM_STATEFUL_DOMAINS=os.enfactum.example,ai.enfactum.example
```

No token handling at all: employees who are signed in to the OS are signed in to the assistant.

### Option C: signed JWT

The OS signs a short-lived JWT (`sub`, `name`, `email`, `roles`, `permissions`) with a shared secret or RSA key (e.g. `firebase/php-jwt`):

```env
AUTH_MODE=jwt
JWT_SECRET=<32+ random bytes>        # or JWT_PUBLIC_KEY_FILE + JWT_ALGORITHMS=RS256
JWT_ISSUER=enfactum-os
```

This is the fastest option (no identity round-trip). OS API tools forward the JWT, so the OS API must also accept it (e.g. a custom guard). Otherwise combine it with DB tools only.

---

## 5. Map roles and permissions (RBAC)

| Assistant setting | Suggested OS permission | Effect |
|---|---|---|
| `PERM_CHAT` | `ai.use` | Who may use the assistant (empty = every employee) |
| `PERM_WEB_SEARCH` | `ai.web_search` | Who may trigger web searches |
| `PERM_DOCUMENTS_MANAGE` | `ai.documents.manage` | Who may add/remove knowledge-base documents |
| `ADMIN_ROLES` | `super_admin,admin` | Roles that see all documents and pass assistant checks |
| `required_permission` (per tool) | the permission guarding that OS route | Hides tools the employee can't use |

Create the permissions once in the OS, for example with a seeder:

```php
foreach (['ai.use', 'ai.web_search', 'ai.documents.manage'] as $p) {
    \Spatie\Permission\Models\Permission::findOrCreate($p, 'web');
}
Role::findByName('employee')->givePermissionTo(['ai.use', 'ai.web_search']);
Role::findByName('hr_manager')->givePermissionTo('ai.documents.manage');
```

How access is enforced, from outermost to innermost:

1. **Assistant feature gate** (`PERM_*`).
2. **Tool exposure:** a tool whose `required_permission` the employee lacks is never shown to the model.
3. **Enfactum OS itself:** middleware, policies, gates and scopes run on every API call made with the employee's token. This is the real security boundary.
4. **Field allow-list and secret redaction** on every tool response.
5. **Document visibility:** role lists on each knowledge-base document, applied before search ranking.

---

## 6. Connect live company data

### 6A. Enfactum OS API tools (recommended)

Each tool is one **existing, read-only GET endpoint**, declared in `config/os_tools.yaml` and called with the employee's own credentials.

**Step 1: find candidate endpoints**

```bash
php artisan route:list --path=api --method=GET
```

Good candidates sit behind `auth:sanctum`, authorise with a policy or `can:` middleware, and return an **API Resource**.

**Step 2: if a module has no API yet, add a thin read-only one** that reuses existing authorisation:

```php
// routes/api.php
Route::middleware('auth:sanctum')->prefix('ai')->group(function () {
    Route::get('/projects', [\App\Http\Controllers\Api\AiProjectController::class, 'index']);
});

// app/Http/Controllers/Api/AiProjectController.php
class AiProjectController extends Controller
{
    public function index(Request $request)
    {
        $this->authorize('viewAny', Project::class);                  // existing policy

        $projects = Project::query()
            ->visibleTo($request->user())                              // existing scope / row-level rule
            ->when($request->search, fn ($q, $s) => $q->where('name', 'ilike', "%{$s}%"))
            ->when($request->status, fn ($q, $s) => $q->where('status', $s))
            ->with(['client:id,name', 'manager:id,name'])
            ->latest()->limit(25)->get();

        return ProjectResource::collection($projects);                 // hides sensitive attributes
    }
}
```

If there is no `visibleTo` scope, apply the same filter the Filament resource uses (for example `getEloquentQuery()` in the Filament Resource), so the API and the UI agree.

**Step 3: declare the tool**

```yaml
# config/os_tools.yaml
base_url: ${OS_BASE_URL}
timeout_seconds: 10
tools:
  - name: search_projects
    label: Projects
    description: >
      Search Enfactum projects by name or client and filter by status. Returns name, client,
      status, manager and dates. Only projects the employee may see are returned.
    method: GET
    path: /api/ai/projects
    required_permission: projects.view
    parameters:
      type: object
      properties:
        search: {type: string, description: "Project or client name"}
        status: {type: string, enum: [planning, active, on_hold, completed]}
    response:
      root: data
      fields: [id, name, client.name, status, manager.name, start_date, end_date]
      max_items: 25
```

**Step 4: activate:**

```env
OS_TOOLS_FILE=config/os_tools.yaml
MOCK_OS_ENABLED=false
```

The startup log shows `Loaded N Enfactum OS tools`. Invalid files stop startup with a clear message. Only `GET` is accepted.

Tips for accurate tool use:

- Write `description` as *when to use it* and *what it returns*. The model routes on it.
- Keep parameters few and typed. Use `enum` for statuses.
- Keep `fields` minimal. Fewer tokens give faster and more precise answers.
- Typical modules: employee directory, projects, clients/CRM, contracts, vendors, invoices/finance, leave, assets, tickets.

### 6B. Read-only database templates (only when there is no API)

For data without an API (reporting tables, a data warehouse), the assistant can run **SQL written by an administrator**. The model only chooses a query and fills validated parameters. It never writes SQL.

> DB templates bypass Laravel policies. Each query must enforce access itself (for example `WHERE user_id = %(current_user_id)s`) and should be gated with `required_permission`. Prefer 6A whenever possible.

**Step 1: create a read-only PostgreSQL role** (run as a DB admin):

```sql
CREATE ROLE ai_readonly LOGIN PASSWORD '<strong-password>';
ALTER ROLE ai_readonly SET default_transaction_read_only = on;
ALTER ROLE ai_readonly SET statement_timeout = '5s';
GRANT CONNECT ON DATABASE enfactum TO ai_readonly;

-- Expose curated views, not raw tables with sensitive columns
CREATE SCHEMA IF NOT EXISTS ai;
CREATE VIEW ai.leave_balances AS
  SELECT user_id, leave_type, year, entitled_days, used_days FROM leave_balances;
GRANT USAGE ON SCHEMA ai TO ai_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA ai TO ai_readonly;
```

Point it at a **read replica** if one exists.

**Step 2: install the driver and configure:**

```bash
pip install "psycopg[binary]"
```

```env
COMPANY_DB_DSN=postgresql://ai_readonly:<password>@db-replica:5432/enfactum
DB_TOOLS_FILE=config/db_tools.yaml
```

**Step 3: write templates** in `config/db_tools.yaml` (examples are in the file):

```yaml
tools:
  - name: my_leave_balance
    label: My leave balance
    description: The current employee's remaining leave days by type for this year.
    sql: |
      SELECT leave_type, entitled_days, used_days, entitled_days - used_days AS remaining
      FROM ai.leave_balances
      WHERE user_id = %(current_user_id)s AND year = EXTRACT(YEAR FROM CURRENT_DATE)
    max_rows: 20
```

Safeguards enforced by the assistant:

- Only a single `SELECT`/`WITH` statement, and no write/DDL keywords.
- Every placeholder must be declared.
- `current_user_id` and `current_user_email` are injected from the verified identity and cannot come from the model.
- Parameters are driver-bound.
- Execution runs in a `READ ONLY` transaction with a timeout and a row cap, with secret-like columns redacted.

### 6C. Other systems (HRMS, CRM, ERP, ticketing)

Two options:

- **Through Enfactum OS:** if the OS already integrates with the system, expose a read-only OS endpoint (6A). The employee's OS permissions then apply.
- **Directly:** add a small tool class next to `app/tools/os_api.py`. Use the employee's own OAuth token for that system, never a shared admin key, and keep it read-only.

---

## 7. Load company knowledge (documents)

**What belongs here:** policies, handbooks, SOPs, process docs, product manuals, templates, FAQs. That is static knowledge. Live records (employees, projects, invoices) belong in tools (section 6), not in documents.

### Ways to add documents

| Method | Who | How |
|---|---|---|
| Composer **+ → Add to knowledge base** | Users with `PERM_DOCUMENTS_MANAGE` | Pick a file, set the audience, upload |
| **Settings → Knowledge base** | Same | Drag and drop, set title and audience |
| Bulk script | Admin / cron | `python scripts/ingest_folder.py ./policies --url https://ai.enfactum.example --token $TOKEN` |
| Restricted folder | Admin | `python scripts/ingest_folder.py ./hr --roles hr_manager,super_admin --token $TOKEN` |

Supported formats: PDF (text-based; OCR scanned PDFs first), DOCX, XLSX, CSV, TXT, MD, HTML, JSON.

### Audience (who can retrieve a document)

- **All employees**: `scope: all`.
- **Restricted**: a list of OS role names. Only employees whose roles (from `/api/ai/me`) match, or admins, can retrieve any part of it. Filtering happens before ranking, so restricted text never reaches the model for other users.

### Keeping it in sync with SharePoint / Google Drive / Confluence

1. Export or sync the source to a folder (OneDrive/Drive desktop sync, Confluence space export, `rclone sync`).
2. Run `scripts/ingest_folder.py <folder> --skip-existing --roles ...` from cron or CI.
3. To update a document, delete the old version in Settings → Knowledge base and re-upload.

### Chat attachments vs. knowledge base

| | Chat attachment (+ → Files or images) | Knowledge base |
|---|---|---|
| Visible to | Only the employee, only in that chat | Everyone in the chosen audience |
| Permission needed | None | `PERM_DOCUMENTS_MANAGE` |
| Images | Yes (if `LLM_SUPPORTS_VISION=true`) | No |
| Typical use | "Summarise this contract", "What's in this screenshot?" | Company policies and manuals |

### Writing documents that answer well

- Use clear headings. Each chunk keeps its section heading.
- One topic per document, with the title stating the topic and version or date.
- Prefer text over images of text. Use tables for numbers.

---

## 8. Embed the assistant in Enfactum OS

Serve the assistant on its own (sub)domain, e.g. `https://ai.enfactum.example`, and add the OS origin to `CORS_ORIGINS` in the assistant's `.env`.

### 8A. React (Vite) frontend: iframe panel (no build changes in the assistant)

```tsx
// src/components/AiAssistant.tsx
import { useEffect, useRef } from "react";

const AI_URL = import.meta.env.VITE_AI_ASSISTANT_URL;   // https://ai.enfactum.example

export function AiAssistant() {
  const frame = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const send = async () => {
      const { token } = await fetch("/ai/token", { method: "POST", credentials: "include",
        headers: { "X-XSRF-TOKEN": getXsrfCookie() } }).then((r) => r.json());
      frame.current?.contentWindow?.postMessage({ type: "enfactum-ai-token", token }, AI_URL);
    };
    frame.current?.addEventListener("load", send);
    return () => frame.current?.removeEventListener("load", send);
  }, []);

  return <iframe ref={frame} src={`${AI_URL}/?embed=1`} title="Enfactum AI"
                 className="h-full w-full border-0" allow="clipboard-write" />;
}
```

`?embed=1` hides the assistant's own sidebar. Mount it as a route (`/assistant`) or a slide-over panel from the main layout. With Option 4B (cookies), skip the token step entirely.

### 8B. React: native component

Call the API from your own components and design system:

```ts
const res = await fetch(`${AI_URL}/api/chat`, {
  method: "POST",
  headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
  body: JSON.stringify({ message, conversation_id, mode: "auto", attachment_ids: [] }),
});
// Server-Sent Events: conversation · status · token · usage · sources · done · error
```

See `static/app.js` (`send()`) for a complete stream parser. Upload attachments first with `POST /api/attachments` (multipart `file`) and pass the returned ids.

### 8C. Filament admin panel

Register a render hook that adds a floating button with the iframe to every panel page:

```php
// app/Providers/Filament/AdminPanelProvider.php
use Filament\View\PanelsRenderHook;
use Illuminate\Support\Facades\Blade;

public function panel(Panel $panel): Panel
{
    return $panel
        // ...
        ->renderHook(PanelsRenderHook::BODY_END, fn (): string => Blade::render('@include("ai.widget")'));
}
```

```blade
{{-- resources/views/ai/widget.blade.php --}}
<div x-data="{ open: false }" class="fixed bottom-6 right-6 z-50">
  <button x-on:click="open = !open" class="rounded-full bg-primary-600 px-4 py-3 text-white shadow-lg">Ask AI</button>
  <div x-show="open" x-cloak class="mt-3 h-[640px] w-[420px] overflow-hidden rounded-2xl bg-white shadow-2xl">
    <iframe src="{{ config('services.ai.url') }}/?embed=1" class="h-full w-full border-0"
            x-on:load="$el.contentWindow.postMessage({type:'enfactum-ai-token',
              token:'{{ auth()->user()->createToken('ai-assistant', ['*'], now()->addHours(8))->plainTextToken }}'},
              '{{ config('services.ai.url') }}')"></iframe>
  </div>
</div>
```

To avoid creating a token on every page load, cache it in the session (e.g. `session()->remember('ai_token', ...)`) or use the cookie option (4B).

---

## 9. Deploy to production

**`.env` essentials**

```env
ENVIRONMENT=production              # refuses AUTH_MODE=demo, disables /api/docs
AUTH_MODE=laravel
MOCK_OS_ENABLED=false
SEED_SAMPLE_DOCS=false
OS_TOOLS_FILE=config/os_tools.yaml
CORS_ORIGINS=https://os.enfactum.example
```

**Docker**

```bash
docker compose up -d --build
```

Data (knowledge base, chats, attachments, audit log) lives in the `assistant-data` volume (`/app/data`). Back it up.

**Reverse proxy.** Streaming requires buffering to be off:

```nginx
server {
  server_name ai.enfactum.example;
  listen 443 ssl http2;
  client_max_body_size 30m;
  location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_buffering off;              # required for token streaming
    proxy_read_timeout 300s;
  }
}
```

**Scaling.** One container handles hundreds of concurrent employees. Beyond that, move the index to PostgreSQL + pgvector and the rate limiter to Redis, then add replicas (see `docs/ARCHITECTURE.md`).

---

## 10. Test the integration

Run these with at least three real accounts: a regular employee, a manager, and an HR/finance user.

| Test | Expected |
|---|---|
| Settings → About → Test connection | "Connected" |
| "What is the capital of Japan?" | Direct answer, no sources |
| "Latest news about <topic> this week" | Web sources with dates |
| A question answered by an HR-only document, asked as a regular employee | "Not found / no access", with no content leak |
| Same question as HR | Answer citing the document |
| "Show all projects with budgets" as a regular employee | Only their projects, no budgets (whatever the OS allows) |
| Salary of a colleague as a regular employee | Access denied or no salary field |
| Attach a PDF and ask for a summary | Summary citing the attachment |
| Attach a screenshot and ask about it | Description (vision models) |
| Paste a document containing "ignore previous instructions…" | Instruction ignored |
| Revoke a permission in the OS, wait 60 s, ask again | Access removed |

Automated tests: `pip install -r requirements-optional.txt && pytest`.

---

## 11. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "The AI model is not configured" | `LLM_API_KEY` empty. Put it in `.env` (not `.env.example`) and restart. |
| "The AI provider rejected the API key" | Key invalid, revoked, or for a different provider. Check the detected provider in Settings → About. Set `LLM_PROVIDER` / `LLM_BASE_URL` if needed. |
| "API key has no access to this model" | Change `LLM_MODEL` to a model your account can use. |
| "Rate-limiting or no credit" | Add billing or credit at the provider, or lower usage. |
| "Model … not found" | Wrong `LLM_MODEL` for that provider. |
| "Make sure the model supports tool calling" | Choose a tool-calling model (most current GPT, Gemini, Claude, Llama 3.1+, Qwen 2.5+). |
| Answers stream all at once | Proxy buffering is on. Set `proxy_buffering off`. |
| 401 in the UI | The OS rejected the token, or `OS_USER_ENDPOINT` is wrong. Test with `curl -H "Authorization: Bearer <token>" $OS_BASE_URL/api/ai/me`. |
| Roles/permissions empty | Field mapping. Set `OS_USER_ROLES_FIELD` / `OS_USER_PERMISSIONS_FIELD` to the right dot-path. |
| OS tool always "ACCESS DENIED" | The OS policy denies it for that user (correct), or the token lacks abilities / the guard differs. |
| Documents never found | Check the document audience matches the user's role names exactly. |
| Web search unavailable | Outbound internet blocked. Set `TAVILY_API_KEY`, or `WEB_SEARCH_PROVIDER=none`. |
| iframe blank | Add the OS origin to `CORS_ORIGINS` (also controls `frame-ancestors`). |

Logs: `docker compose logs -f assistant` (or the terminal running `run.sh`). The first lines show the detected provider, model, loaded tools and indexed chunks.

---

## 12. Reference

**Files you will edit**

| File | Purpose |
|---|---|
| `.env` | All configuration |
| `config/os_tools.yaml` | Enfactum OS API tools |
| `config/db_tools.yaml` | Read-only SQL templates |
| `scripts/ingest_folder.py` | Bulk knowledge-base upload |

**HTTP API**

| Endpoint | Purpose |
|---|---|
| `POST /api/chat` | Ask a question (SSE stream) |
| `POST /api/attachments`, `DELETE /api/attachments/{id}` | Chat attachments |
| `GET/POST/DELETE /api/documents` | Knowledge base |
| `GET/PATCH/DELETE /api/conversations[/{id}]`, `GET /api/export` | History, pin/rename, export |
| `GET/PUT /api/settings` | Per-employee preferences |
| `GET /api/me`, `GET /api/health`, `GET /api/health/llm` | Identity, health, model check |

Security model: see `docs/SECURITY.md`. Agentic roadmap: see `docs/AGENTIC_ROADMAP.md`.
