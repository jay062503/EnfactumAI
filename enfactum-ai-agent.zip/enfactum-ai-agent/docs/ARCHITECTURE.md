# Architecture

## Components

```mermaid
flowchart LR
    U[Employee browser<br/>Assistant UI or Enfactum OS React] -->|Bearer token / cookies| API[FastAPI<br/>app/main.py]
    API --> AUTH[AuthService<br/>app/auth.py]
    AUTH -->|GET /api/user with user's token| OS[(Enfactum OS<br/>Laravel API)]
    API --> AG[Agent loop<br/>app/agent.py]
    AG <-->|stream + tool calls| LLM[LLM<br/>OpenAI-compatible]
    AG --> T1[web_search]
    AG --> T2[search_company_documents]
    AG --> T3[OS API tools<br/>config/os_tools.yaml]
    T1 --> WEB[(Tavily / DuckDuckGo)]
    T2 --> IDX[Hybrid index<br/>BM25 + vectors + ACL]
    IDX --> DB[(SQLite<br/>docs, chunks, chats, audit)]
    T3 -->|GET with user's token| OS
```

## Knowledge routing

```text
Question
  ├─ General knowledge          → LLM answers directly (no tool round-trip)
  ├─ Public / current info      → web_search → cited web results
  └─ Private Enfactum info
        ├─ policies / documents → search_company_documents → permission-filtered chunks
        └─ live business data   → Enfactum OS tool(s) → OS enforces the user's access
```

Routing is done by the LLM through native tool calling, guided by the system prompt (`app/prompts.py`). Users can override it with the mode selector:

| Mode | Behaviour |
|---|---|
| Auto | Model chooses; can call several tools in parallel |
| General | No tools |
| Web | Web search runs immediately (no model round-trip first), then the model answers |
| Company | Document search runs immediately; OS tools stay available |

## Request flow (`POST /api/chat`)

```text
Browser ── POST /api/chat (SSE) ──► current_user()
                                      └─ AuthService: demo | laravel (/api/user) | jwt  → UserContext (cached 60s)
                                   ► RateLimiter
                                   ► Agent.run()
                                      1. tools = registry.for_user(user, mode)     # unpermitted tools never offered
                                      2. messages = system prompt + last N turns + question
                                      3. loop (≤ MAX_TOOL_ROUNDS):
                                           stream LLM ──► tokens forwarded to browser immediately
                                           tool calls? ─► re-check allowed set, validate args,
                                                          run in parallel (25s timeout each),
                                                          wrap results as untrusted data, audit log
                                      4. keep only sources actually cited [n]; persist the answer
Browser ◄── events: conversation · status · token · sources · done
```

## Accuracy design

- **Grounding rules:** Enfactum and current-events claims must come from tool results; empty or denied results must be stated rather than guessed.
- **Citations:** every tool result is numbered through a shared `Citations` registry, and the model cites `[n]`. The UI shows only sources that were actually cited.
- **Hybrid retrieval:** BM25 (exact terms, names, codes) and dense vectors (semantics) are fused with Reciprocal Rank Fusion. Chunks keep their section heading, so retrieved fragments stay self-describing.
- **Web depth:** Tavily advanced search returns multi-chunk content. With DuckDuckGo, the top N pages are fetched in full concurrently.
- **Clean history:** old citation markers are stripped from history so stale numbers can't be re-cited.

## Performance design

- Token streaming from the first byte, with status events while tools run.
- General questions skip tools entirely (single LLM call).
- Parallel tool calls (`parallel_tool_calls`), executed with `asyncio.gather`.
- Forced modes pre-run retrieval, saving a full model round-trip.
- Shared `httpx` connection pool, LRU cache for query embeddings, 60 s identity cache.
- In-memory index (NumPy matrix + inverted index): millisecond retrieval up to roughly 100k chunks.

## Storage

SQLite (`DATA_DIR/assistant.db`, WAL mode):

- `documents` / `chunks`: knowledge base with per-document `visibility` JSON and float32 embeddings.
- `conversations` / `messages`: per-user history, always queried with `user_id`.
- `audit_log`: tool calls (name and arguments, not results), denied tool attempts, document uploads/deletes.

## Scaling path

The current design targets one container with one async worker, which is enough for hundreds of concurrent employees. For more:

1. Move chunks/embeddings to PostgreSQL + pgvector (Enfactum already runs PostgreSQL) or Qdrant, and replace `DocumentIndex` (the interface is a single `search(query, user, k)`).
2. Move the rate limiter and identity cache to Redis.
3. Then run several replicas behind a load balancer.
