import logging

from openai import AsyncOpenAI, BadRequestError

from .config import Settings

log = logging.getLogger(__name__)


class LLM:
    """OpenAI-compatible chat client (OpenAI, Azure, Groq, OpenRouter, vLLM, Ollama, LM Studio...)."""

    def __init__(self, settings: Settings):
        self.s = settings
        self.client = AsyncOpenAI(base_url=settings.llm_base_url, api_key=settings.llm_api_key or "not-needed",
                                  timeout=settings.llm_timeout_seconds, max_retries=2)
        self._parallel_supported = True

    async def stream(self, messages: list[dict], tools: list[dict] | None = None):
        kwargs = dict(model=self.s.llm_model, messages=messages, temperature=self.s.llm_temperature,
                      max_tokens=self.s.llm_max_tokens, stream=True)
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
            if self._parallel_supported:
                kwargs["parallel_tool_calls"] = True
        try:
            return await self.client.chat.completions.create(**kwargs)
        except BadRequestError as exc:
            if "parallel_tool_calls" not in kwargs:
                raise
            log.info("Provider rejected parallel_tool_calls (%s); disabling it", exc)
            self._parallel_supported = False
            kwargs.pop("parallel_tool_calls")
            return await self.client.chat.completions.create(**kwargs)
