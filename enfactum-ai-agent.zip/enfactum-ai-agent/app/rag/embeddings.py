import asyncio
import logging
import time
from collections import OrderedDict

import numpy as np
from openai import AsyncOpenAI

from ..config import Settings

log = logging.getLogger(__name__)


class Embedder:
    """Produces L2-normalised float32 vectors, or None when embeddings are unavailable (retrieval then uses BM25)."""

    def __init__(self, settings: Settings):
        self.s = settings
        self.provider = settings.embedding_provider.lower()
        self._client: AsyncOpenAI | None = None
        self._local = None
        self._disabled_until = 0.0
        self._cache: OrderedDict[str, np.ndarray] = OrderedDict()
        if self.provider == "llm":
            self._client = AsyncOpenAI(
                base_url=settings.embedding_base_url or settings.llm_base_url,
                api_key=settings.embedding_api_key or settings.llm_api_key or "not-needed",
                timeout=30,
            )

    @property
    def enabled(self) -> bool:
        return self.provider in ("llm", "local") and time.time() >= self._disabled_until

    async def embed_documents(self, texts: list[str]) -> list[np.ndarray] | None:
        if not self.enabled or not texts:
            return None
        out: list[np.ndarray] = []
        try:
            for i in range(0, len(texts), 64):
                out.extend(await self._embed(texts[i:i + 64]))
            return out
        except Exception as exc:
            self._fail(exc)
            return None

    async def embed_query(self, text: str) -> np.ndarray | None:
        if not self.enabled:
            return None
        if text in self._cache:
            self._cache.move_to_end(text)
            return self._cache[text]
        try:
            vec = (await self._embed([text]))[0]
        except Exception as exc:
            self._fail(exc)
            return None
        self._cache[text] = vec
        if len(self._cache) > 512:
            self._cache.popitem(last=False)
        return vec

    async def _embed(self, texts: list[str]) -> list[np.ndarray]:
        if self.provider == "local":
            vectors = await asyncio.to_thread(self._local_embed, texts)
        else:
            resp = await self._client.embeddings.create(model=self.s.embedding_model, input=texts)
            vectors = [np.asarray(d.embedding, dtype=np.float32) for d in resp.data]
        return [v / (np.linalg.norm(v) or 1.0) for v in vectors]

    def _local_embed(self, texts: list[str]) -> list[np.ndarray]:
        if self._local is None:
            from fastembed import TextEmbedding

            self._local = TextEmbedding(model_name=self.s.local_embedding_model)
        return [np.asarray(v, dtype=np.float32) for v in self._local.embed(texts)]

    def _fail(self, exc: Exception) -> None:
        log.warning("Embeddings unavailable (%s); using keyword search for 5 minutes", exc)
        self._disabled_until = time.time() + 300
