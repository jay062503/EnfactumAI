import asyncio
from pathlib import Path

import numpy as np

from ..config import Settings
from ..db import Database
from .chunker import chunk_text
from .embeddings import Embedder
from .index import DocumentIndex
from .parsers import parse_document


class Ingestor:
    def __init__(self, settings: Settings, db: Database, embedder: Embedder, index: DocumentIndex):
        self.s = settings
        self.db = db
        self.embedder = embedder
        self.index = index
        self._lock = asyncio.Lock()

    async def ingest(self, *, filename: str, data: bytes, title: str | None, visibility: dict, uploaded_by: str,
                     mime: str = "") -> dict:
        sections = await asyncio.to_thread(parse_document, filename, data)
        title = (title or Path(filename).stem.replace("_", " ").replace("-", " ")).strip()[:200]
        pieces: list[tuple[int | None, str]] = []
        for text, page in sections:
            for chunk in chunk_text(text, self.s.rag_chunk_size, self.s.rag_chunk_overlap):
                pieces.append((page, chunk))
        vectors = await self.embedder.embed_documents([f"{title}\n{c}" for _, c in pieces])
        rows = [(i, page, text, vectors[i].astype(np.float32).tobytes() if vectors else None)
                for i, (page, text) in enumerate(pieces)]
        async with self._lock:
            doc_id = self.db.add_document(title=title, filename=filename, mime=mime, size_bytes=len(data),
                                          uploaded_by=uploaded_by, visibility=visibility, chunks=rows)
            await asyncio.to_thread(self.index.reload)
        return {"id": doc_id, "title": title, "chunks": len(rows), "embedded": bool(vectors)}

    async def delete(self, doc_id: str) -> None:
        async with self._lock:
            self.db.delete_document(doc_id)
            await asyncio.to_thread(self.index.reload)
