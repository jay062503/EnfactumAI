import asyncio
import json
import logging
import re
import time
from collections.abc import AsyncIterator

from .auth import UserContext
from .config import Settings
from .db import Database
from .llm import LLM
from .prompts import build_system_prompt
from .tools.base import Citations, Tool, ToolContext
from .tools.registry import ToolRegistry

log = logging.getLogger(__name__)
_CITE = re.compile(r"\[(\d{1,3})\]")
TOOL_TIMEOUT = 25


class Agent:
    def __init__(self, settings: Settings, llm: LLM, registry: ToolRegistry, db: Database):
        self.s = settings
        self.llm = llm
        self.registry = registry
        self.db = db

    async def run(self, user: UserContext, conversation_id: str, message: str, mode: str) -> AsyncIterator[dict]:
        started = time.perf_counter()
        tools = self.registry.for_user(user, mode)
        allowed = {t.name: t for t in tools}
        history = self.db.get_messages(conversation_id, limit=self.s.history_turns * 2)
        self.db.add_message(conversation_id, "user", message, meta={"mode": mode})

        messages: list[dict] = [{"role": "system", "content": build_system_prompt(user, tools, mode)}]
        for m in history:
            messages.append({"role": m["role"], "content": _CITE.sub("", m["content"]).strip()})
        messages.append({"role": "user", "content": message})

        ctx = ToolContext(user=user, citations=Citations())
        used: list[str] = []
        answer_parts: list[str] = []

        try:
            # Explicit Web / Company modes: run the retrieval immediately instead of waiting a model round-trip.
            forced = [n for n in (("web_search",) if mode == "web" else ("search_company_documents",) if mode == "company" else ())
                      if n in allowed]
            if forced:
                calls = [{"id": f"prefetch_{i}", "name": n, "arguments": json.dumps({"query": message})}
                         for i, n in enumerate(forced)]
                async for event in self._execute(calls, allowed, ctx, messages, used, ""):
                    yield event

            for round_no in range(self.s.max_tool_rounds):
                offer = tools if round_no < self.s.max_tool_rounds - 1 else []
                stream = await self.llm.stream(messages, [t.schema() for t in offer] or None)
                text_parts: list[str] = []
                calls: dict[int, dict] = {}
                async for chunk in stream:
                    if not chunk.choices:
                        continue
                    delta = chunk.choices[0].delta
                    if delta.content:
                        text_parts.append(delta.content)
                        yield {"type": "token", "text": delta.content}
                    for tc in delta.tool_calls or []:
                        slot = calls.setdefault(tc.index or 0, {"id": "", "name": "", "arguments": ""})
                        if tc.id:
                            slot["id"] = tc.id
                        if tc.function:
                            if tc.function.name and tc.function.name != slot["name"]:
                                slot["name"] += tc.function.name
                            if tc.function.arguments:
                                slot["arguments"] += tc.function.arguments
                text = "".join(text_parts)
                if text:
                    answer_parts.append(text)
                if not calls:
                    break
                ordered = []
                for i, (_, c) in enumerate(sorted(calls.items())):
                    c["id"] = c["id"] or f"call_{round_no}_{i}"
                    ordered.append(c)
                if text:
                    yield {"type": "token", "text": "\n\n"}
                async for event in self._execute(ordered, allowed, ctx, messages, used, text):
                    yield event
        except Exception as exc:
            log.exception("Agent run failed")
            yield {"type": "error", "message": _friendly_error(exc)}

        answer = "\n\n".join(answer_parts).strip()
        cited = {int(n) for n in _CITE.findall(answer)}
        sources = [s for s in ctx.citations.items if s["n"] in cited]
        latency_ms = int((time.perf_counter() - started) * 1000)
        msg_id = None
        if answer:
            msg_id = self.db.add_message(conversation_id, "assistant", answer, sources=sources,
                                         meta={"mode": mode, "tools": used, "latency_ms": latency_ms})
        yield {"type": "sources", "sources": sources}
        yield {"type": "done", "message_id": msg_id, "latency_ms": latency_ms, "tools": used}

    async def _execute(self, calls: list[dict], allowed: dict[str, Tool], ctx: ToolContext, messages: list[dict],
                       used: list[str], assistant_text: str) -> AsyncIterator[dict]:
        messages.append({
            "role": "assistant", "content": assistant_text or None,
            "tool_calls": [{"id": c["id"], "type": "function",
                            "function": {"name": c["name"], "arguments": c["arguments"] or "{}"}} for c in calls],
        })
        parsed = []
        for c in calls:
            try:
                args = json.loads(c["arguments"] or "{}")
                if not isinstance(args, dict):
                    raise ValueError
            except ValueError:
                args = None
            tool = allowed.get(c["name"])
            parsed.append((c, tool, args))
            label = tool.status_text(args or {}) if tool else c["name"]
            yield {"type": "status", "id": c["id"], "state": "running", "label": label,
                   "kind": tool.kind if tool else "unknown"}

        results = await asyncio.gather(*(self._run_one(c, tool, args, ctx) for c, tool, args in parsed))
        for (c, tool, _), result in zip(parsed, results):
            if tool:
                used.append(tool.name)
            messages.append({"role": "tool", "tool_call_id": c["id"], "content": result})
            yield {"type": "status", "id": c["id"], "state": "done"}

    async def _run_one(self, call: dict, tool: Tool | None, args: dict | None, ctx: ToolContext) -> str:
        if tool is None:
            # Unknown, hallucinated, or not permitted for this user: never executed.
            self.db.audit(ctx.user.id, "tool_denied", {"tool": call["name"]})
            return f"Error: tool '{call['name']}' is not available to this user."
        if args is None:
            return "Error: arguments were not valid JSON. Retry with a valid JSON object."
        self.db.audit(ctx.user.id, "tool_call", {"tool": tool.name, "args": args})
        try:
            return await asyncio.wait_for(tool.run(args, ctx), timeout=TOOL_TIMEOUT)
        except asyncio.TimeoutError:
            return f"Error: {tool.name} timed out. Tell the user this source is slow right now."
        except Exception as exc:
            log.exception("Tool %s failed", tool.name)
            return f"Error: {tool.name} failed ({type(exc).__name__})."


def _friendly_error(exc: Exception) -> str:
    name = type(exc).__name__
    if name in ("AuthenticationError", "PermissionDeniedError"):
        return "The AI model rejected the API key. Check LLM_API_KEY."
    if name == "RateLimitError":
        return "The AI model is rate-limited right now. Please retry in a moment."
    if name in ("APIConnectionError", "APITimeoutError"):
        return "Could not reach the AI model. Check LLM_BASE_URL and network connectivity."
    if name == "NotFoundError":
        return "The configured model was not found. Check LLM_MODEL."
    if name == "BadRequestError":
        return "The AI model rejected the request. Make sure LLM_MODEL supports tool calling."
    return "Something went wrong while generating the answer. Please try again."
