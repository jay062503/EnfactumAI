import asyncio
import json
import logging
import re
import time
from collections.abc import AsyncIterator

from .attachments import IMAGE_TOKEN_ESTIMATE, build_document_context, estimate_tokens, image_parts
from .auth import UserContext
from .config import Settings
from .db import Database
from .llm import LLM, friendly_error
from .prompts import build_system_prompt
from .tools.base import Citations, Tool, ToolContext
from .tools.registry import ToolRegistry

log = logging.getLogger(__name__)
_CITE = re.compile(r"\[(\d{1,3})\]")
TOOL_TIMEOUT = 25
TOOL_RESERVE_TOKENS = 6000


class Agent:
    def __init__(self, settings: Settings, llm: LLM, registry: ToolRegistry, db: Database):
        self.s = settings
        self.llm = llm
        self.registry = registry
        self.db = db

    @property
    def context_window(self) -> int:
        return self.llm.profile.context_window

    async def run(self, user: UserContext, conversation_id: str, message: str, mode: str,
                  new_attachments: list[dict] | None = None, prefs: dict | None = None) -> AsyncIterator[dict]:
        started = time.perf_counter()
        tools = self.registry.for_user(user, mode)
        allowed = {t.name: t for t in tools}
        new_attachments = new_attachments or []
        history = self.db.get_messages(conversation_id, limit=self.s.history_turns * 2)
        self.db.add_message(conversation_id, "user", message, meta={
            "mode": mode, "attachments": [{"id": a["id"], "name": a["name"], "kind": a["kind"]} for a in new_attachments]})

        ctx = ToolContext(user=user, citations=Citations())
        system = build_system_prompt(user, tools, mode, prefs)

        # Current turn: question + every document attached to this conversation + images attached now.
        all_atts = self.db.conversation_attachments(conversation_id, user.id)
        budget = min(self.s.attachment_context_chars, max(4000, (self.context_window - self.s.llm_max_tokens) * 2))
        doc_context = build_document_context(all_atts, message, budget, ctx.citations)
        text = f"{doc_context}\n\n{message}" if doc_context else message
        images = image_parts(new_attachments) if self.llm_supports_vision else []
        if new_attachments and not self.llm_supports_vision and any(a["kind"] == "image" for a in new_attachments):
            text += "\n\n(The employee attached an image, but the configured model cannot read images. Say so.)"
        user_content = [{"type": "text", "text": text}, *images] if images else text

        fixed = estimate_tokens(system) + estimate_tokens(text) + len(images) * IMAGE_TOKEN_ESTIMATE
        history_budget = self.context_window - self.s.llm_max_tokens - TOOL_RESERVE_TOKENS - fixed
        past: list[dict] = []
        for m in reversed(history):
            content = _CITE.sub("", m["content"]).strip()
            names = [a["name"] for a in (m.get("meta") or {}).get("attachments", [])]
            if names:
                content = f"[attached: {', '.join(names)}] {content}"
            cost = estimate_tokens(content) + 4
            if history_budget - cost < 0:
                break
            history_budget -= cost
            past.insert(0, {"role": m["role"], "content": content})

        messages: list[dict] = [{"role": "system", "content": system}, *past, {"role": "user", "content": user_content}]
        used: list[str] = []
        answer_parts: list[str] = []
        usage = {"prompt": 0, "completion": 0, "reported": False}

        try:
            forced = [n for n in (("web_search",) if mode == "web" else ("search_company_documents",)
                                  if mode == "company" else ()) if n in allowed]
            if forced:
                calls = [{"id": f"prefetch_{i}", "name": n, "arguments": json.dumps({"query": message})}
                         for i, n in enumerate(forced)]
                async for event in self._execute(calls, allowed, ctx, messages, used, ""):
                    yield event

            for round_no in range(self.s.max_tool_rounds):
                offer = tools if round_no < self.s.max_tool_rounds - 1 else []
                stream = await self.llm.stream(messages, [t.schema() for t in offer] or None)
                text_parts: list[str] = []
                calls: dict[int, dict] = {}
                async for chunk in stream:
                    if getattr(chunk, "usage", None):
                        usage.update(prompt=chunk.usage.prompt_tokens or 0,
                                     completion=chunk.usage.completion_tokens or 0, reported=True)
                    if not chunk.choices:
                        continue
                    delta = chunk.choices[0].delta
                    if delta.content:
                        text_parts.append(delta.content)
                        yield {"type": "token", "text": delta.content}
                    for tc in delta.tool_calls or []:
                        slot = calls.setdefault(tc.index or 0, {"id": "", "name": "", "arguments": ""})
                        if tc.id:
                            slot["id"] = tc.id
                        if tc.function:
                            if tc.function.name and tc.function.name != slot["name"]:
                                slot["name"] += tc.function.name
                            if tc.function.arguments:
                                slot["arguments"] += tc.function.arguments
                text_out = "".join(text_parts)
                if text_out:
                    answer_parts.append(text_out)
                if not calls:
                    break
                ordered = []
                for i, (_, c) in enumerate(sorted(calls.items())):
                    c["id"] = c["id"] or f"call_{round_no}_{i}"
                    ordered.append(c)
                if text_out:
                    yield {"type": "token", "text": "\n\n"}
                async for event in self._execute(ordered, allowed, ctx, messages, used, text_out):
                    yield event
        except Exception as exc:
            log.exception("Agent run failed")
            yield {"type": "error", "message": friendly_error(exc)}

        answer = "\n\n".join(answer_parts).strip()
        cited = {int(n) for n in _CITE.findall(answer)}
        sources = [s for s in ctx.citations.items if s["n"] in cited]
        latency_ms = int((time.perf_counter() - started) * 1000)
        if not usage["reported"]:
            usage["prompt"] = sum(_estimate_message(m) for m in messages)
            usage["completion"] = estimate_tokens(answer)
        context = {"used": usage["prompt"] + usage["completion"], "window": self.context_window,
                   "estimated": not usage["reported"]}
        yield {"type": "usage", **context}
        msg_id = None
        if answer:
            msg_id = self.db.add_message(conversation_id, "assistant", answer, sources=sources,
                                         meta={"mode": mode, "tools": used, "latency_ms": latency_ms,
                                               "context": context})
        yield {"type": "sources", "sources": sources}
        yield {"type": "done", "message_id": msg_id, "latency_ms": latency_ms, "tools": used}

    @property
    def llm_supports_vision(self) -> bool:
        return self.s.llm_supports_vision

    async def _execute(self, calls: list[dict], allowed: dict[str, Tool], ctx: ToolContext, messages: list[dict],
                       used: list[str], assistant_text: str) -> AsyncIterator[dict]:
        messages.append({
            "role": "assistant", "content": assistant_text or None,
            "tool_calls": [{"id": c["id"], "type": "function",
                            "function": {"name": c["name"], "arguments": c["arguments"] or "{}"}} for c in calls],
        })
        parsed = []
        for c in calls:
            try:
                args = json.loads(c["arguments"] or "{}")
                if not isinstance(args, dict):
                    raise ValueError
            except ValueError:
                args = None
            tool = allowed.get(c["name"])
            parsed.append((c, tool, args))
            label = tool.status_text(args or {}) if tool else c["name"]
            yield {"type": "status", "id": c["id"], "state": "running", "label": label,
                   "kind": tool.kind if tool else "unknown"}

        results = await asyncio.gather(*(self._run_one(c, tool, args, ctx) for c, tool, args in parsed))
        for (c, tool, _), result in zip(parsed, results):
            if tool:
                used.append(tool.name)
            messages.append({"role": "tool", "tool_call_id": c["id"], "content": result})
            yield {"type": "status", "id": c["id"], "state": "done"}

    async def _run_one(self, call: dict, tool: Tool | None, args: dict | None, ctx: ToolContext) -> str:
        if tool is None:
            self.db.audit(ctx.user.id, "tool_denied", {"tool": call["name"]})
            return f"Error: tool '{call['name']}' is not available to this user."
        if args is None:
            return "Error: arguments were not valid JSON. Retry with a valid JSON object."
        self.db.audit(ctx.user.id, "tool_call", {"tool": tool.name, "args": args})
        try:
            return await asyncio.wait_for(tool.run(args, ctx), timeout=TOOL_TIMEOUT)
        except asyncio.TimeoutError:
            return f"Error: {tool.name} timed out. Tell the user this source is slow right now."
        except Exception as exc:
            log.exception("Tool %s failed", tool.name)
            return f"Error: {tool.name} failed ({type(exc).__name__})."


def _estimate_message(m: dict) -> int:
    content = m.get("content") or ""
    if isinstance(content, list):
        return sum(estimate_tokens(p.get("text", "")) if p.get("type") == "text" else IMAGE_TOKEN_ESTIMATE
                   for p in content) + 4
    extra = sum(estimate_tokens(c["function"]["arguments"]) + 10 for c in m.get("tool_calls", []))
    return estimate_tokens(content) + extra + 4
