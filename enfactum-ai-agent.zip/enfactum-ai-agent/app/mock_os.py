"""A tiny stand-in for Enfactum OS, used only for local demos (MOCK_OS_ENABLED=true).

It behaves like a Laravel API protected by Sanctum + permissions: it authenticates the bearer token, enforces
permissions and row-level visibility itself, and returns {"data": [...]} payloads. All records are fictional.
"""
from fastapi import APIRouter, Header, HTTPException, Query

from .auth import load_demo_users
from .config import Settings

EMPLOYEES = [
    {"id": 101, "name": "Aisha Khan", "email": "aisha.khan@enfactum.example", "department": "Leadership",
     "designation": "Chief Operating Officer", "manager": None, "location": "Singapore", "salary": 310000},
    {"id": 102, "name": "Rohan Mehta", "email": "rohan.mehta@enfactum.example", "department": "People & Culture",
     "designation": "HR Manager", "manager": "Aisha Khan", "location": "Mumbai", "salary": 145000},
    {"id": 103, "name": "Priya Nair", "email": "priya.nair@enfactum.example", "department": "Delivery",
     "designation": "Senior Project Manager", "manager": "Aisha Khan", "location": "Bengaluru", "salary": 128000},
    {"id": 104, "name": "Daniel Lim", "email": "daniel.lim@enfactum.example", "department": "Design",
     "designation": "UX Lead", "manager": "Priya Nair", "location": "Singapore", "salary": 118000},
    {"id": 105, "name": "Sara Iyer", "email": "sara.iyer@enfactum.example", "department": "Engineering",
     "designation": "Full-stack Engineer", "manager": "Priya Nair", "location": "Bengaluru", "salary": 92000},
    {"id": 106, "name": "Marcus Tan", "email": "marcus.tan@enfactum.example", "department": "Finance",
     "designation": "Finance Controller", "manager": "Aisha Khan", "location": "Singapore", "salary": 150000},
]

CLIENTS = [
    {"id": 201, "name": "Northwind Retail", "industry": "Retail", "account_manager": "Priya Nair", "status": "active"},
    {"id": 202, "name": "Helios Energy", "industry": "Energy", "account_manager": "Aisha Khan", "status": "active"},
    {"id": 203, "name": "BlueHarbor Bank", "industry": "Financial Services", "account_manager": "Priya Nair",
     "status": "prospect"},
]

PROJECTS = [
    {"id": 301, "name": "Northwind Omnichannel App", "client": "Northwind Retail", "status": "in_progress",
     "manager": "Priya Nair", "start_date": "2026-03-02", "end_date": "2026-11-30", "budget": 420000,
     "team": ["Priya Nair", "Daniel Lim", "Sara Iyer"]},
    {"id": 302, "name": "Helios Customer Portal", "client": "Helios Energy", "status": "planning",
     "manager": "Aisha Khan", "start_date": "2026-10-15", "end_date": "2027-04-30", "budget": 610000,
     "team": ["Aisha Khan", "Marcus Tan"]},
    {"id": 303, "name": "BlueHarbor Discovery Sprint", "client": "BlueHarbor Bank", "status": "proposal",
     "manager": "Priya Nair", "start_date": None, "end_date": None, "budget": 55000, "team": ["Priya Nair"]},
]


def build_router(settings: Settings) -> APIRouter:
    users = {u["os_token"]: u for u in load_demo_users(settings).values() if u.get("os_token")}
    router = APIRouter(prefix="/mock-os/api", tags=["mock-os"], include_in_schema=False)

    def auth(authorization: str | None) -> dict:
        token = (authorization or "").removeprefix("Bearer ").strip()
        user = users.get(token)
        if not user:
            raise HTTPException(401, "Unauthenticated.")
        return user

    def can(user: dict, perm: str) -> bool:
        return "super_admin" in user.get("roles", []) or perm in user.get("permissions", [])

    def require(user: dict, perm: str) -> None:
        if not can(user, perm):
            raise HTTPException(403, "This action is unauthorized.")

    def match(record: dict, q: str | None, *keys: str) -> bool:
        return not q or any(q.lower() in str(record.get(k) or "").lower() for k in keys)

    @router.get("/user")
    def me(authorization: str | None = Header(None)):
        u = auth(authorization)
        return {"id": u["id"], "name": u["name"], "email": u.get("email"), "roles": u.get("roles", []),
                "permissions": u.get("permissions", [])}

    @router.get("/employees")
    def employees(search: str | None = Query(None), department: str | None = Query(None),
                  authorization: str | None = Header(None)):
        u = auth(authorization)
        require(u, "employees.view")
        rows = [e for e in EMPLOYEES if match(e, search, "name", "email", "designation")
                and match(e, department, "department")]
        if not can(u, "employees.view_salary"):
            rows = [{k: v for k, v in e.items() if k != "salary"} for e in rows]
        return {"data": rows, "meta": {"total": len(rows)}}

    @router.get("/employees/{employee_id}")
    def employee(employee_id: int, authorization: str | None = Header(None)):
        u = auth(authorization)
        require(u, "employees.view")
        for e in EMPLOYEES:
            if e["id"] == employee_id:
                return {"data": e if can(u, "employees.view_salary") else {k: v for k, v in e.items() if k != "salary"}}
        raise HTTPException(404, "Not found.")

    @router.get("/projects")
    def projects(search: str | None = Query(None), status: str | None = Query(None),
                 authorization: str | None = Header(None)):
        u = auth(authorization)
        require(u, "projects.view")
        rows = [p for p in PROJECTS if match(p, search, "name", "client") and (not status or p["status"] == status)]
        if not can(u, "projects.view_all"):
            rows = [p for p in rows if u["name"] in p["team"]]
        if not can(u, "finance.view"):
            rows = [{k: v for k, v in p.items() if k != "budget"} for p in rows]
        return {"data": rows, "meta": {"total": len(rows)}}

    @router.get("/clients")
    def clients(search: str | None = Query(None), authorization: str | None = Header(None)):
        u = auth(authorization)
        require(u, "clients.view")
        rows = [c for c in CLIENTS if match(c, search, "name", "industry")]
        return {"data": rows, "meta": {"total": len(rows)}}

    return router
