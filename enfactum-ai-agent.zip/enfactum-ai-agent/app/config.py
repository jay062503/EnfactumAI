from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent


def csv_list(value: str) -> list[str]:
    return [item.strip() for item in (value or "").split(",") if item.strip()]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=BASE_DIR / ".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Enfactum AI Assistant"
    host: str = "0.0.0.0"
    port: int = 8080
    environment: str = "development"
    cors_origins: str = ""
    data_dir: Path = Path("data")

    llm_base_url: str = "https://api.openai.com/v1"
    llm_api_key: str = ""
    llm_model: str = "gpt-4o-mini"
    llm_temperature: float = 0.2
    llm_max_tokens: int = 1800
    llm_timeout_seconds: float = 60

    embedding_provider: str = "llm"
    embedding_base_url: str = ""
    embedding_api_key: str = ""
    embedding_model: str = "text-embedding-3-small"
    local_embedding_model: str = "BAAI/bge-small-en-v1.5"

    web_search_provider: str = "auto"
    tavily_api_key: str = ""
    web_search_max_results: int = 5
    web_fetch_pages: int = 2

    auth_mode: str = "demo"
    demo_users_file: Path = Path("config/demo_users.yaml")
    os_base_url: str = ""
    os_user_endpoint: str = "/api/user"
    os_user_id_field: str = "id"
    os_user_name_field: str = "name"
    os_user_email_field: str = "email"
    os_user_roles_field: str = "roles"
    os_user_permissions_field: str = "permissions"
    os_forward_cookies: bool = False
    os_verify_ssl: bool = True
    auth_cache_seconds: int = 60

    jwt_secret: str = ""
    jwt_public_key_file: str = ""
    jwt_algorithms: str = "HS256"
    jwt_audience: str = ""
    jwt_issuer: str = ""

    os_tools_file: Path = Path("config/os_tools.yaml")
    mock_os_enabled: bool = False
    seed_sample_docs: bool = False

    admin_roles: str = "super_admin,admin"
    perm_chat: str = ""
    perm_web_search: str = ""
    perm_documents_manage: str = "ai.documents.manage"

    rag_chunk_size: int = 1200
    rag_chunk_overlap: int = 200
    rag_top_k: int = 6
    max_upload_mb: int = 25
    max_tool_rounds: int = 4
    history_turns: int = 8
    rate_limit_per_minute: int = 30

    @field_validator("data_dir", "demo_users_file", "os_tools_file", mode="after")
    @classmethod
    def _resolve_path(cls, value: Path) -> Path:
        return value if value.is_absolute() else (BASE_DIR / value).resolve()

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"

    @property
    def admin_role_set(self) -> frozenset[str]:
        return frozenset(csv_list(self.admin_roles))


@lru_cache
def get_settings() -> Settings:
    return Settings()
