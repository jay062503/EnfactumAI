import json
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    filename TEXT NOT NULL,
    mime TEXT,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    uploaded_by TEXT NOT NULL,
    visibility TEXT NOT NULL,
    chunk_count INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    ord INTEGER NOT NULL,
    page INTEGER,
    text TEXT NOT NULL,
    embedding BLOB
);
CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(document_id);
CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id, updated_at DESC);
CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    sources TEXT,
    meta TEXT,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id, created_at);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    detail TEXT
);
"""


class Database:
    """Thin thread-safe SQLite store. All queries are parameterised; no LLM-generated SQL ever reaches it."""

    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
            self._conn.executescript(SCHEMA)
            self._conn.commit()

    def _exec(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self._conn.execute(sql, params)
            self._conn.commit()
            return cur

    def _all(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]

    def _one(self, sql: str, params: tuple = ()) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute(sql, params).fetchone()
            return dict(row) if row else None

    # ---- documents -------------------------------------------------------
    def add_document(self, *, title: str, filename: str, mime: str, size_bytes: int, uploaded_by: str,
                     visibility: dict, chunks: list[tuple[int, int | None, str, bytes | None]]) -> str:
        doc_id = uuid.uuid4().hex
        with self._lock:
            self._conn.execute(
                "INSERT INTO documents (id, title, filename, mime, size_bytes, uploaded_by, visibility, chunk_count, created_at)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (doc_id, title, filename, mime, size_bytes, uploaded_by, json.dumps(visibility), len(chunks), time.time()),
            )
            self._conn.executemany(
                "INSERT INTO chunks (document_id, ord, page, text, embedding) VALUES (?,?,?,?,?)",
                [(doc_id, ord_, page, text, emb) for ord_, page, text, emb in chunks],
            )
            self._conn.commit()
        return doc_id

    def list_documents(self) -> list[dict[str, Any]]:
        rows = self._all("SELECT * FROM documents ORDER BY created_at DESC")
        for r in rows:
            r["visibility"] = json.loads(r["visibility"])
        return rows

    def get_document(self, doc_id: str) -> dict[str, Any] | None:
        row = self._one("SELECT * FROM documents WHERE id=?", (doc_id,))
        if row:
            row["visibility"] = json.loads(row["visibility"])
        return row

    def delete_document(self, doc_id: str) -> None:
        self._exec("DELETE FROM documents WHERE id=?", (doc_id,))

    def all_chunks(self) -> list[dict[str, Any]]:
        return self._all(
            "SELECT c.id, c.document_id, c.ord, c.page, c.text, c.embedding, d.title, d.visibility"
            " FROM chunks c JOIN documents d ON d.id = c.document_id ORDER BY c.document_id, c.ord"
        )

    def count_documents(self) -> int:
        row = self._one("SELECT COUNT(*) AS n FROM documents")
        return int(row["n"]) if row else 0

    # ---- conversations ---------------------------------------------------
    def create_conversation(self, user_id: str, title: str) -> str:
        conv_id = uuid.uuid4().hex
        now = time.time()
        self._exec("INSERT INTO conversations (id, user_id, title, created_at, updated_at) VALUES (?,?,?,?,?)",
                   (conv_id, user_id, title, now, now))
        return conv_id

    def get_conversation(self, conv_id: str, user_id: str) -> dict[str, Any] | None:
        return self._one("SELECT * FROM conversations WHERE id=? AND user_id=?", (conv_id, user_id))

    def list_conversations(self, user_id: str, limit: int = 100) -> list[dict[str, Any]]:
        return self._all("SELECT id, title, updated_at FROM conversations WHERE user_id=? ORDER BY updated_at DESC LIMIT ?",
                         (user_id, limit))

    def delete_conversation(self, conv_id: str, user_id: str) -> bool:
        return self._exec("DELETE FROM conversations WHERE id=? AND user_id=?", (conv_id, user_id)).rowcount > 0

    def add_message(self, conv_id: str, role: str, content: str, sources: list | None = None,
                    meta: dict | None = None) -> str:
        msg_id = uuid.uuid4().hex
        now = time.time()
        with self._lock:
            self._conn.execute(
                "INSERT INTO messages (id, conversation_id, role, content, sources, meta, created_at) VALUES (?,?,?,?,?,?,?)",
                (msg_id, conv_id, role, content, json.dumps(sources or []), json.dumps(meta or {}), now),
            )
            self._conn.execute("UPDATE conversations SET updated_at=? WHERE id=?", (now, conv_id))
            self._conn.commit()
        return msg_id

    def get_messages(self, conv_id: str, limit: int | None = None) -> list[dict[str, Any]]:
        if limit:
            rows = self._all("SELECT * FROM (SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT ?)"
                             " ORDER BY created_at ASC", (conv_id, limit))
        else:
            rows = self._all("SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at ASC", (conv_id,))
        for r in rows:
            r["sources"] = json.loads(r["sources"] or "[]")
            r["meta"] = json.loads(r["meta"] or "{}")
        return rows

    # ---- audit -----------------------------------------------------------
    def audit(self, user_id: str, action: str, detail: dict | None = None) -> None:
        self._exec("INSERT INTO audit_log (ts, user_id, action, detail) VALUES (?,?,?,?)",
                   (time.time(), user_id, action, json.dumps(detail or {}, default=str)[:4000]))
