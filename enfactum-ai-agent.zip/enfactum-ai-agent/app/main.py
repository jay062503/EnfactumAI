import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import yaml
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .agent import Agent
from .auth import AuthService, UserContext
from .config import BASE_DIR, csv_list, get_settings
from .db import Database
from .llm import LLM
from .rag.embeddings import Embedder
from .rag.index import DocumentIndex, can_view
from .rag.ingest import Ingestor
from .rag.parsers import SUPPORTED_EXTENSIONS, UnsupportedDocument
from .security import RateLimiter, SecurityHeadersMiddleware
from .tools.documents import DocumentSearchTool
from .tools.os_api import load_os_tools
from .tools.registry import MODES, ToolRegistry
from .tools.web_search import WebSearchTool

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("enfactum")
settings = get_settings()
STATIC_DIR = BASE_DIR / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    http = httpx.AsyncClient(verify=settings.os_verify_ssl, limits=httpx.Limits(max_connections=100))
    db = Database(settings.data_dir / "assistant.db")
    embedder = Embedder(settings)
    index = DocumentIndex(db, embedder)
    index.reload()
    ingestor = Ingestor(settings, db, embedder, index)

    tools = [DocumentSearchTool(settings, index)]
    web = WebSearchTool(settings, http)
    if web.enabled:
        tools.insert(0, web)
    tools.extend(load_os_tools(settings, http))
    registry = ToolRegistry(tools)

    app.state.db = db
    app.state.index = index
    app.state.ingestor = ingestor
    app.state.registry = registry
    app.state.auth = AuthService(settings, http)
    app.state.agent = Agent(settings, LLM(settings), registry, db)
    app.state.limiter = RateLimiter(settings.rate_limit_per_minute)

    if settings.seed_sample_docs and db.count_documents() == 0:
        await _seed_samples(ingestor)
    if not settings.llm_api_key and "api.openai.com" in settings.llm_base_url:
        log.warning("LLM_API_KEY is empty: chat will fail until it is set in .env")
    log.info("Ready: model=%s auth=%s tools=%s docs_chunks=%d", settings.llm_model, settings.auth_mode,
             [t.name for t in registry.all()], index.size)
    yield
    await http.aclose()


app = FastAPI(title=settings.app_name, version=__version__, lifespan=lifespan,
              docs_url=None if settings.is_production else "/api/docs", redoc_url=None)
app.add_middleware(SecurityHeadersMiddleware, frame_ancestors=" ".join(csv_list(settings.cors_origins)))
if settings.cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=csv_list(settings.cors_origins), allow_credentials=True,
                       allow_methods=["GET", "POST", "DELETE"], allow_headers=["Authorization", "Content-Type",
                                                                                 "X-Demo-User"])
if settings.mock_os_enabled:
    from .mock_os import build_router

    app.include_router(build_router(settings))


async def current_user(request: Request) -> UserContext:
    user = await request.app.state.auth.authenticate(request)
    if not user.can(settings.perm_chat or None):
        raise HTTPException(403, "You do not have access to the AI assistant")
    return user


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/health")
async def health(request: Request):
    return {"status": "ok", "version": __version__, "indexed_chunks": request.app.state.index.size}


@app.get("/api/config")
async def public_config(request: Request):
    cfg = {"app_name": settings.app_name, "auth_mode": settings.auth_mode, "modes": list(MODES),
           "max_upload_mb": settings.max_upload_mb, "supported_extensions": sorted(SUPPORTED_EXTENSIONS),
           "trusted_origins": csv_list(settings.cors_origins),
           "cookie_auth": settings.auth_mode == "laravel" and settings.os_forward_cookies}
    if settings.auth_mode == "demo":
        cfg["demo_users"] = [{"id": u["id"], "name": u["name"], "title": u.get("title", ""),
                              "roles": u.get("roles", [])} for u in request.app.state.auth.demo_users.values()]
    return cfg


@app.get("/api/me")
async def me(request: Request, user: UserContext = Depends(current_user)):
    tools = request.app.state.registry.for_user(user)
    return {"user": user.public(),
            "capabilities": {"web_search": any(t.kind == "web" for t in tools),
                             "documents_manage": user.can(settings.perm_documents_manage or None),
                             "os_tools": [t.label for t in tools if t.kind == "company"]}}


# ---------------------------------------------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    conversation_id: str | None = None
    mode: str = "auto"


@app.post("/api/chat")
async def chat(body: ChatRequest, request: Request, user: UserContext = Depends(current_user)):
    request.app.state.limiter.check(user.id)
    db: Database = request.app.state.db
    mode = body.mode if body.mode in MODES else "auto"
    message = body.message.strip()
    if body.conversation_id:
        if not db.get_conversation(body.conversation_id, user.id):
            raise HTTPException(404, "Conversation not found")
        conv_id = body.conversation_id
    else:
        conv_id = db.create_conversation(user.id, _title(message))

    async def events():
        yield _sse({"type": "conversation", "id": conv_id})
        async for event in request.app.state.agent.run(user, conv_id, message, mode):
            yield _sse(event)

    return StreamingResponse(events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/api/conversations")
async def list_conversations(request: Request, user: UserContext = Depends(current_user)):
    return {"conversations": request.app.state.db.list_conversations(user.id)}


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str, request: Request, user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    conv = db.get_conversation(conv_id, user.id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    msgs = [{"id": m["id"], "role": m["role"], "content": m["content"], "sources": m["sources"],
             "meta": m["meta"]} for m in db.get_messages(conv_id)]
    return {"id": conv["id"], "title": conv["title"], "messages": msgs}


@app.delete("/api/conversations/{conv_id}")
async def delete_conversation(conv_id: str, request: Request, user: UserContext = Depends(current_user)):
    if not request.app.state.db.delete_conversation(conv_id, user.id):
        raise HTTPException(404, "Conversation not found")
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/documents")
async def list_documents(request: Request, user: UserContext = Depends(current_user)):
    docs = [d for d in request.app.state.db.list_documents() if can_view(d["visibility"], user)]
    return {"documents": [{k: d[k] for k in ("id", "title", "filename", "size_bytes", "chunk_count", "created_at",
                                              "visibility")} for d in docs],
            "can_manage": user.can(settings.perm_documents_manage or None)}


@app.post("/api/documents")
async def upload_document(request: Request, file: UploadFile = File(...), title: str = Form(""),
                          visibility: str = Form("all"), roles: str = Form(""),
                          user: UserContext = Depends(current_user)):
    if not user.can(settings.perm_documents_manage or None):
        raise HTTPException(403, "You are not allowed to manage company documents")
    limit = settings.max_upload_mb * 1024 * 1024
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File exceeds {settings.max_upload_mb} MB")
    vis = {"scope": "all"} if visibility != "restricted" else {"scope": "restricted", "roles": csv_list(roles)}
    if vis["scope"] == "restricted" and not vis["roles"]:
        raise HTTPException(422, "Restricted documents need at least one role")
    filename = Path(file.filename or "document.txt").name
    try:
        result = await request.app.state.ingestor.ingest(filename=filename, data=data, title=title or None,
                                                         visibility=vis, uploaded_by=user.id,
                                                         mime=file.content_type or "")
    except UnsupportedDocument as exc:
        raise HTTPException(422, str(exc)) from exc
    request.app.state.db.audit(user.id, "document_upload", {"id": result["id"], "title": result["title"]})
    return result


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str, request: Request, user: UserContext = Depends(current_user)):
    if not user.can(settings.perm_documents_manage or None):
        raise HTTPException(403, "You are not allowed to manage company documents")
    if not request.app.state.db.get_document(doc_id):
        raise HTTPException(404, "Document not found")
    await request.app.state.ingestor.delete(doc_id)
    request.app.state.db.audit(user.id, "document_delete", {"id": doc_id})
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------------------
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


def _title(message: str) -> str:
    first = " ".join(message.split())
    return first[:60] + ("…" if len(first) > 60 else "")


async def _seed_samples(ingestor: Ingestor) -> None:
    manifest = BASE_DIR / "samples" / "manifest.yaml"
    if not manifest.exists():
        return
    for item in (yaml.safe_load(manifest.read_text()) or {}).get("documents", []):
        path = manifest.parent / item["file"]
        try:
            await ingestor.ingest(filename=path.name, data=path.read_bytes(), title=item.get("title"),
                                  visibility=item.get("visibility", {"scope": "all"}), uploaded_by="system")
            log.info("Seeded sample document: %s", item.get("title"))
        except Exception as exc:
            log.warning("Could not seed %s: %s", path.name, exc)
