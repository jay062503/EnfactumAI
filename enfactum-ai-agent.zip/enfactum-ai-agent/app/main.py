import json
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import yaml
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .agent import Agent
from .attachments import ATTACHMENT_EXTENSIONS, save_attachment
from .auth import AuthService, UserContext
from .config import BASE_DIR, csv_list, get_settings
from .db import Database
from .llm import LLM
from .rag.embeddings import Embedder
from .rag.index import DocumentIndex, can_view
from .rag.ingest import Ingestor
from .rag.parsers import SUPPORTED_EXTENSIONS, UnsupportedDocument
from .security import RateLimiter, SecurityHeadersMiddleware
from .tools.db_query import load_db_tools
from .tools.documents import DocumentSearchTool
from .tools.os_api import load_os_tools
from .tools.registry import MODES, ToolRegistry
from .tools.web_search import WebSearchTool

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("enfactum")
settings = get_settings()
STATIC_DIR = BASE_DIR / "static"

DEFAULT_PREFS = {
    "theme": "system",            # system | light | dark
    "default_mode": "auto",       # auto | general | web | company
    "enter_to_send": True,
    "show_context_meter": True,
    "response_length": "balanced",  # concise | balanced | detailed
    "about_me": "",
    "response_instructions": "",
}
PREF_CHOICES = {"theme": {"system", "light", "dark"}, "default_mode": set(MODES),
                "response_length": {"concise", "balanced", "detailed"}}


@asynccontextmanager
async def lifespan(app: FastAPI):
    http = httpx.AsyncClient(verify=settings.os_verify_ssl, limits=httpx.Limits(max_connections=100))
    db = Database(settings.data_dir / "assistant.db")
    embedder = Embedder(settings)
    index = DocumentIndex(db, embedder)
    index.reload()
    ingestor = Ingestor(settings, db, embedder, index)

    tools = [DocumentSearchTool(settings, index)]
    web = WebSearchTool(settings, http)
    if web.enabled:
        tools.insert(0, web)
    tools.extend(load_os_tools(settings, http))
    tools.extend(load_db_tools(settings))
    registry = ToolRegistry(tools)
    llm = LLM(settings)

    app.state.db = db
    app.state.index = index
    app.state.ingestor = ingestor
    app.state.registry = registry
    app.state.llm = llm
    app.state.auth = AuthService(settings, http)
    app.state.agent = Agent(settings, llm, registry, db)
    app.state.limiter = RateLimiter(settings.rate_limit_per_minute)

    if settings.seed_sample_docs and db.count_documents() == 0:
        await _seed_samples(ingestor)
    log.info("Ready: auth=%s tools=%s docs_chunks=%d", settings.auth_mode, [t.name for t in registry.all()], index.size)
    yield
    await http.aclose()


app = FastAPI(title=settings.app_name, version=__version__, lifespan=lifespan,
              docs_url=None if settings.is_production else "/api/docs", redoc_url=None)
app.add_middleware(SecurityHeadersMiddleware, frame_ancestors=" ".join(csv_list(settings.cors_origins)))
if settings.cors_origins:
    app.add_middleware(CORSMiddleware, allow_origins=csv_list(settings.cors_origins), allow_credentials=True,
                       allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
                       allow_headers=["Authorization", "Content-Type", "X-Demo-User"])
if settings.mock_os_enabled:
    from .mock_os import build_router

    app.include_router(build_router(settings))


async def current_user(request: Request) -> UserContext:
    user = await request.app.state.auth.authenticate(request)
    if not user.can(settings.perm_chat or None):
        raise HTTPException(403, "You do not have access to the AI assistant")
    return user


def user_prefs(db: Database, user_id: str) -> dict:
    return {**DEFAULT_PREFS, **db.get_settings(user_id)}


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/health")
async def health(request: Request):
    return {"status": "ok", "version": __version__, "indexed_chunks": request.app.state.index.size}


@app.get("/api/health/llm")
async def health_llm(request: Request, user: UserContext = Depends(current_user)):
    return await request.app.state.llm.check()


@app.get("/api/config")
async def public_config():
    return {"app_name": settings.app_name, "auth_mode": settings.auth_mode, "modes": list(MODES),
            "max_upload_mb": settings.max_upload_mb, "max_attachment_mb": settings.max_attachment_mb,
            "supported_extensions": sorted(SUPPORTED_EXTENSIONS),
            "attachment_extensions": sorted(ATTACHMENT_EXTENSIONS),
            "trusted_origins": csv_list(settings.cors_origins),
            "cookie_auth": settings.auth_mode == "laravel" and settings.os_forward_cookies}


@app.get("/api/me")
async def me(request: Request, user: UserContext = Depends(current_user)):
    tools = request.app.state.registry.for_user(user)
    profile = request.app.state.llm.profile
    return {"user": user.public(),
            "settings": user_prefs(request.app.state.db, user.id),
            "model": {"provider": profile.provider, "name": profile.model, "context_window": profile.context_window,
                      "vision": settings.llm_supports_vision, "configured": not profile.key_missing},
            "capabilities": {"web_search": any(t.kind == "web" for t in tools),
                             "documents_manage": user.can(settings.perm_documents_manage or None),
                             "os_tools": [t.label for t in tools if t.kind == "company"]},
            "version": __version__}


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/settings")
async def get_user_settings(request: Request, user: UserContext = Depends(current_user)):
    return user_prefs(request.app.state.db, user.id)


@app.put("/api/settings")
async def put_user_settings(body: dict, request: Request, user: UserContext = Depends(current_user)):
    current = user_prefs(request.app.state.db, user.id)
    for key, value in body.items():
        if key not in DEFAULT_PREFS:
            continue
        default = DEFAULT_PREFS[key]
        if isinstance(default, bool):
            current[key] = bool(value)
        elif key in PREF_CHOICES:
            if value not in PREF_CHOICES[key]:
                raise HTTPException(422, f"Invalid value for {key}")
            current[key] = value
        else:
            current[key] = str(value or "")[:1500]
    request.app.state.db.save_settings(user.id, current)
    return current


# ---------------------------------------------------------------------------------------------------------------
class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=8000)
    conversation_id: str | None = None
    mode: str = "auto"
    attachment_ids: list[str] = Field(default_factory=list, max_length=10)


@app.post("/api/chat")
async def chat(body: ChatRequest, request: Request, user: UserContext = Depends(current_user)):
    request.app.state.limiter.check(user.id)
    db: Database = request.app.state.db
    mode = body.mode if body.mode in MODES else "auto"
    message = body.message.strip()
    attachments = []
    for att_id in body.attachment_ids:
        att = db.get_attachment(att_id, user.id)
        if not att or (att["conversation_id"] and att["conversation_id"] != body.conversation_id):
            raise HTTPException(404, "Attachment not found")
        attachments.append(att)
    if body.conversation_id:
        if not db.get_conversation(body.conversation_id, user.id):
            raise HTTPException(404, "Conversation not found")
        conv_id = body.conversation_id
    else:
        conv_id = db.create_conversation(user.id, _title(message))
    for att in attachments:
        db.link_attachment(att["id"], user.id, conv_id)
    prefs = user_prefs(db, user.id)

    async def events():
        yield _sse({"type": "conversation", "id": conv_id})
        async for event in request.app.state.agent.run(user, conv_id, message, mode, attachments, prefs):
            yield _sse(event)

    return StreamingResponse(events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/conversations")
async def list_conversations(request: Request, user: UserContext = Depends(current_user)):
    rows = request.app.state.db.list_conversations(user.id)
    return {"conversations": [{**r, "pinned": bool(r["pinned"])} for r in rows]}


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str, request: Request, user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    conv = db.get_conversation(conv_id, user.id)
    if not conv:
        raise HTTPException(404, "Conversation not found")
    msgs = [{"id": m["id"], "role": m["role"], "content": m["content"], "sources": m["sources"],
             "meta": m["meta"]} for m in db.get_messages(conv_id)]
    return {"id": conv["id"], "title": conv["title"], "pinned": bool(conv.get("pinned")), "messages": msgs}


class ConversationPatch(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    pinned: bool | None = None


@app.patch("/api/conversations/{conv_id}")
async def patch_conversation(conv_id: str, body: ConversationPatch, request: Request,
                             user: UserContext = Depends(current_user)):
    if not request.app.state.db.update_conversation(conv_id, user.id, title=body.title, pinned=body.pinned):
        raise HTTPException(404, "Conversation not found")
    return {"ok": True}


@app.delete("/api/conversations/{conv_id}")
async def delete_conversation(conv_id: str, request: Request, user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    files = [a["file_path"] for a in db.conversation_attachments(conv_id, user.id) if a["file_path"]]
    if not db.delete_conversation(conv_id, user.id):
        raise HTTPException(404, "Conversation not found")
    _unlink(files)
    return {"ok": True}


@app.delete("/api/conversations")
async def delete_all_conversations(request: Request, user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    files = db.attachment_files_for_user(user.id)
    count = db.delete_all_conversations(user.id)
    _unlink(files)
    db.audit(user.id, "conversations_delete_all", {"count": count})
    return {"deleted": count}


@app.get("/api/export")
async def export_conversations(request: Request, user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    data = {"exported_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "user": user.public(),
            "conversations": [{"id": c["id"], "title": c["title"], "pinned": bool(c["pinned"]),
                               "messages": [{"role": m["role"], "content": m["content"], "sources": m["sources"],
                                             "created_at": m["created_at"]} for m in db.get_messages(c["id"])]}
                              for c in db.list_conversations(user.id, limit=10_000)]}
    return JSONResponse(data, headers={"Content-Disposition": 'attachment; filename="enfactum-ai-chats.json"'})


# ---------------------------------------------------------------------------------------------------------------
@app.post("/api/attachments")
async def upload_attachment(request: Request, file: UploadFile = File(...), conversation_id: str = Form(""),
                            user: UserContext = Depends(current_user)):
    db: Database = request.app.state.db
    if conversation_id and not db.get_conversation(conversation_id, user.id):
        raise HTTPException(404, "Conversation not found")
    limit = settings.max_attachment_mb * 1024 * 1024
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File exceeds {settings.max_attachment_mb} MB")
    filename = Path(file.filename or "file.txt").name
    try:
        return await save_attachment(settings, db, user_id=user.id, conversation_id=conversation_id or None,
                                     filename=filename, data=data, mime=file.content_type or "")
    except UnsupportedDocument as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/api/attachments/{att_id}/file")
async def attachment_file(att_id: str, request: Request, user: UserContext = Depends(current_user)):
    row = request.app.state.db.get_attachment(att_id, user.id)
    if not row or row["kind"] != "image" or not row["file_path"] or not Path(row["file_path"]).exists():
        raise HTTPException(404, "Attachment not found")
    return FileResponse(row["file_path"], media_type=row["mime"], headers={"Cache-Control": "private, max-age=86400"})


@app.delete("/api/attachments/{att_id}")
async def delete_attachment(att_id: str, request: Request, user: UserContext = Depends(current_user)):
    row = request.app.state.db.delete_attachment(att_id, user.id)
    if not row:
        raise HTTPException(404, "Attachment not found")
    _unlink([row["file_path"]] if row["file_path"] else [])
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------------------
@app.get("/api/documents")
async def list_documents(request: Request, user: UserContext = Depends(current_user)):
    docs = [d for d in request.app.state.db.list_documents() if can_view(d["visibility"], user)]
    return {"documents": [{k: d[k] for k in ("id", "title", "filename", "size_bytes", "chunk_count", "created_at",
                                              "visibility")} for d in docs],
            "can_manage": user.can(settings.perm_documents_manage or None)}


@app.post("/api/documents")
async def upload_document(request: Request, file: UploadFile = File(...), title: str = Form(""),
                          visibility: str = Form("all"), roles: str = Form(""),
                          user: UserContext = Depends(current_user)):
    if not user.can(settings.perm_documents_manage or None):
        raise HTTPException(403, "You are not allowed to manage company documents")
    limit = settings.max_upload_mb * 1024 * 1024
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File exceeds {settings.max_upload_mb} MB")
    vis = {"scope": "all"} if visibility != "restricted" else {"scope": "restricted", "roles": csv_list(roles)}
    if vis["scope"] == "restricted" and not vis["roles"]:
        raise HTTPException(422, "Restricted documents need at least one role")
    filename = Path(file.filename or "document.txt").name
    try:
        result = await request.app.state.ingestor.ingest(filename=filename, data=data, title=title or None,
                                                         visibility=vis, uploaded_by=user.id,
                                                         mime=file.content_type or "")
    except UnsupportedDocument as exc:
        raise HTTPException(422, str(exc)) from exc
    request.app.state.db.audit(user.id, "document_upload", {"id": result["id"], "title": result["title"]})
    return result


@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str, request: Request, user: UserContext = Depends(current_user)):
    if not user.can(settings.perm_documents_manage or None):
        raise HTTPException(403, "You are not allowed to manage company documents")
    if not request.app.state.db.get_document(doc_id):
        raise HTTPException(404, "Document not found")
    await request.app.state.ingestor.delete(doc_id)
    request.app.state.db.audit(user.id, "document_delete", {"id": doc_id})
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------------------
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
async def index():
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


def _title(message: str) -> str:
    first = " ".join(message.split())
    return first[:60] + ("…" if len(first) > 60 else "")


def _unlink(paths: list[str]) -> None:
    root = (settings.data_dir / "attachments").resolve()
    for p in paths:
        path = Path(p).resolve()
        if root in path.parents:
            path.unlink(missing_ok=True)


async def _seed_samples(ingestor: Ingestor) -> None:
    manifest = BASE_DIR / "samples" / "manifest.yaml"
    if not manifest.exists():
        return
    for item in (yaml.safe_load(manifest.read_text()) or {}).get("documents", []):
        path = manifest.parent / item["file"]
        try:
            await ingestor.ingest(filename=path.name, data=path.read_bytes(), title=item.get("title"),
                                  visibility=item.get("visibility", {"scope": "all"}), uploaded_by="system")
            log.info("Seeded sample document: %s", item.get("title"))
        except Exception as exc:
            log.warning("Could not seed %s: %s", path.name, exc)
